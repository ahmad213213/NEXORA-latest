@echo off
setlocal EnableExtensions
title NEXORA — UI Preview (no install)
color 0B
cls
echo ================================================================
echo              NEXORA  —  FROSTED-GLASS UI PREVIEW
echo ================================================================
echo.
echo This opens the approved Desktop + Console prototype in your browser.
echo No installation, no Node.js, no Electron required.
echo.
echo Features you can try:
echo   - Desktop sidebar navigation
echo   - DualSense-style Console Mode toggle (top-right controller icon)
echo   - Settings screens (local preview store)
echo   - Empty library + rotating backgrounds
echo.
echo NOTE: This is a visual prototype only.
echo Game adding, real streaming, and native window controls
echo require the full Electron build (later phases).
echo.

set "PREVIEW=%~dp0design-reference\current-frosted-glass-ui-prototype\index.html"
if not exist "%PREVIEW%" (
  echo [ERROR] Prototype not found:
  echo   "%PREVIEW%"
  echo.
  pause
  exit /b 1
)

echo Opening: "%PREVIEW%"
start "" "%PREVIEW%"
if errorlevel 1 (
  echo.
  echo Could not open automatically. Open this file manually in a browser:
  echo   "%PREVIEW%"
  pause
  exit /b 1
)

echo.
echo Preview launched. You can close this window.
timeout /t 4 >nul
endlocal
exit /b 0
