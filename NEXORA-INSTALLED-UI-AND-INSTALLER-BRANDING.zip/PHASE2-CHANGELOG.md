# Phase 2 — Game Library & ORBIT Metadata

## Goal
Make the game library trustworthy, persistent, and resilient to provider failures.

## What was already solid (preserved)
- Executable path validation (Windows `.exe` only, rejects reserved characters)
- Duplicate detection by normalized exe path
- Pending → verified / failed lifecycle
- ORBIT add flow: beginAdd → search → choose → commitOrbit (atomic save)
- Cover + screenshot download, enhancement, and disk cache under `userData/covers` and `userData/shots`
- Pin / unpin / remove / markPlayed
- ORBIT search cache (successful results only; failures are never cached)
- `Promise.allSettled` across metadata providers so one failure cannot crash the flow
- IPC trust checks; renderer cannot supply download URLs

## What Phase 2 hardened
1. **library-store.ts**
   - Serialized writes (`saveChain`) so rapid pin/remove/markPlayed cannot collide on one temp file
   - Unique temp file per write (`pid` + sequence)
   - Stricter `isGameRecord` validation on load — a single corrupt entry no longer risks wiping valid games
   - Private file mode `0o600`

2. **Regression tests** — `apps/host/test/library-phase2.test.mjs`
   - Path validation, duplicate handling, pin/unpin, play state
   - Provider failure isolation (`allSettled`)
   - ORBIT cache policy (no cache of failures)
   - Artwork disk paths and size limits
   - Steam provider timeout / trusted hosts / size limits
   - UI textContent-only ORBIT rendering
   - Malformed library.json recovery contract

3. **package.json**
   - Added `test:library` convenience script

## Design-reference checkpoint
Still untouched under `design-reference/current-frosted-glass-ui-prototype/`.

## How to verify
```bat
pnpm test:library
pnpm test
pnpm dev:host
```
Manual: Add Game → pick exe → ORBIT match → confirm → pin → restart → still there → remove.

## Known limitations (environment)
- Full network ORBIT search against live Steam/providers was not executed in this sandbox.
- Real executable launch is Phase 3.
