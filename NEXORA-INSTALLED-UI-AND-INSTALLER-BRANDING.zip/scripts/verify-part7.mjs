import fs from 'node:fs'; import path from 'node:path';
const root=process.cwd(); const req=[
'packages/shared/src/control-layout.ts','apps/host/src/layout/layout-store.ts','apps/host/src/layout/layout-controller.ts','apps/host/src/input/input-manager.ts','apps/receiver/android/app/src/main/java/com/nexora/receiver/gameplay/ControlOverlayView.kt','docs/PART7-CONTROL-LAYOUT-SPEC.md','apps/host/test/control-layout.test.mjs'];
let n=0; for(const f of req){if(!fs.existsSync(path.join(root,f))) throw new Error(`missing ${f}`); n++}
const shared=fs.readFileSync(path.join(root,'packages/shared/src/control-layout.ts'),'utf8');
for(const x of ['controls.length>24','opacity','x','y','width','height','version']) if(!shared.includes(x)) throw new Error(`missing contract ${x}`); n++;
const main=fs.readFileSync(path.join(root,'apps/host/src/main.ts'),'utf8'); for(const x of ['layout:list','layout:save','layout:remove','isTrustedSender']) if(!main.includes(x)) throw new Error(`missing IPC security ${x}`); n++;
const preload=fs.readFileSync(path.join(root,'apps/host/src/preload.cts'),'utf8'); for(const x of ['listLayouts','saveLayout','removeLayout']) if(!preload.includes(x)) throw new Error(`missing preload ${x}`); n++;
const kt=fs.readFileSync(path.join(root,'apps/receiver/android/app/src/main/java/com/nexora/receiver/gameplay/ControlOverlayView.kt'),'utf8'); if(kt.includes('private val controls = listOf')) throw new Error('hardcoded controls remain'); n++;
console.log(`Part 7 static verification: ${n}/11 PASS`);
