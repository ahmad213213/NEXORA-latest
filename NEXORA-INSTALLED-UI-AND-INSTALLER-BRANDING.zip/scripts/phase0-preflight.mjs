import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const required = [
  'package.json', 'pnpm-workspace.yaml', 'apps/host/package.json',
  'apps/host/src/main.ts', 'apps/host/src/preload.cts',
  'apps/host/src/ui/index.html', 'apps/host/src/ui/styles.css',
  'apps/host/src/ui/app.js', 'apps/host/src/ui/assets/dualsense-mode.svg',
  'packages/shared/package.json', 'packages/shared/src/index.ts',
  'apps/receiver/android/app/src/main/AndroidManifest.xml',
  'PREVIEW.bat',
  'design-reference/current-frosted-glass-ui-prototype/index.html',
  'design-reference/current-frosted-glass-ui-prototype/app.js',
  'design-reference/current-frosted-glass-ui-prototype/styles.css',
  'design-reference/previews/preview-desktop.png',
];
let failed = 0;
const ok = (msg) => console.log(`PASS  ${msg}`);
const fail = (msg) => { console.error(`FAIL  ${msg}`); failed++; };
const warn = (msg) => console.warn(`WARN  ${msg}`);

console.log('NEXORA Phase 1 cumulative source preflight');
console.log(`Project: ${root}`);
for (const rel of required) {
  if (fs.existsSync(path.join(root, rel))) ok(`required file: ${rel}`);
  else fail(`missing required file: ${rel}`);
}

for (const rel of ['package.json', 'apps/host/package.json', 'packages/shared/package.json']) {
  try { JSON.parse(fs.readFileSync(path.join(root, rel), 'utf8')); ok(`valid JSON: ${rel}`); }
  catch (e) { fail(`invalid JSON: ${rel} (${e.message})`); }
}

const packageJson = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
if (packageJson.packageManager === 'pnpm@10.17.1') ok('package manager is pinned to pnpm@10.17.1');
else fail(`unexpected packageManager: ${packageJson.packageManager ?? '(missing)'}`);
if (packageJson.devDependencies?.['electron-builder'] === '26.0.12') ok('electron-builder version is pinned locally to 26.0.12');
else fail('electron-builder is not pinned to 26.0.12 as expected');

const previewBat = fs.readFileSync(path.join(root, 'PREVIEW.bat'), 'utf8');
if (/apps\\host\\src\\ui\\index\.html/i.test(previewBat)) ok('PREVIEW.bat opens the live Electron renderer');
else fail('PREVIEW.bat does not target the live Electron renderer');
for (const rel of ['make-installer.bat', 'Make-Program.bat', 'Bootstrap-Phase0.bat']) {
  if (fs.existsSync(path.join(root, rel))) fail(`${rel} should be deferred in this Phase 1 source-only package`);
}
ok('program-build, dependency-bootstrap, and installer BAT files are deferred; PREVIEW.bat is the only root BAT file');

const renderer = path.join(root, 'apps/host/src/ui/app.js');
const check = spawnSync(process.execPath, ['--check', renderer], { encoding: 'utf8' });
if (check.status === 0) ok('live Electron renderer JavaScript syntax');
else fail(`live renderer syntax check failed: ${(check.stderr || check.stdout).trim()}`);

const htmlPath = path.join(root, 'apps/host/src/ui/index.html');
const html = fs.readFileSync(htmlPath, 'utf8');
let refs = 0;
for (const [, value] of html.matchAll(/(?:src|href)=["']([^"']+)["']/g)) {
  if (/^(?:#|https?:|data:|mailto:|javascript:)/i.test(value)) continue;
  refs++;
  const resolved = path.resolve(path.dirname(htmlPath), value);
  if (fs.existsSync(resolved)) ok(`live UI asset: ${value}`);
  else fail(`missing live UI asset: ${value}`);
}
console.log(`Live UI local asset references checked: ${refs}`);

const lock = path.join(root, 'pnpm-lock.yaml');
if (fs.existsSync(lock)) ok('pnpm-lock.yaml exists');
else warn('pnpm-lock.yaml is not included; generate it during a later build phase on a network-enabled machine');

const nm = path.join(root, 'node_modules');
if (fs.existsSync(nm)) warn('node_modules is present in the source folder; do not distribute it or rely on it as the dependency source');
else ok('source package excludes node_modules');

if (failed) {
  console.error(`\nPreflight failed: ${failed} issue(s).`);
  process.exitCode = 1;
} else {
  console.log('\nPreflight passed. Warnings, if any, are listed above; this is a structural check, not an Electron/NSIS runtime certification.');
}
