import fs from 'node:fs';
import path from 'node:path';
const root = new URL('../', import.meta.url).pathname;
const checks = [
  ['shared input frame exists', fs.existsSync(path.join(root,'packages/shared/src/input-frame.ts'))],
  ['host input data channel exists', fs.existsSync(path.join(root,'apps/host/src/input/input-data-channel.ts'))],
  ['Android input sender exists', fs.existsSync(path.join(root,'apps/receiver/android/app/src/main/java/com/nexora/receiver/input/InputDataChannelSender.kt'))],
  ['Android WebRTC exposes input channel', fs.readFileSync(path.join(root,'apps/receiver/android/app/src/main/java/com/nexora/receiver/webrtc/WebRtcReceiver.kt'),'utf8').includes('createInputDataChannel')],
  ['fixed input channel label', fs.readFileSync(path.join(root,'packages/shared/src/input-frame.ts'),'utf8').includes('nexora-input-v1')],
  ['frame size cap', fs.readFileSync(path.join(root,'packages/shared/src/input-frame.ts'),'utf8').includes('MAX_INPUT_FRAME_BYTES')],
  ['host replay-safe manager retained', fs.readFileSync(path.join(root,'apps/host/src/input/input-manager.ts'),'utf8').includes('event.sequence <= this.lastSequence')],
  ['release reset detaches channel', fs.readFileSync(path.join(root,'apps/host/src/integration/session-orchestrator.ts'),'utf8').includes('this.inputChannel.detach()')],
  ['stage docs exist', fs.existsSync(path.join(root,'docs/INTEGRATION-STAGE3-INPUT.md'))],
  ['no screenshot UI hack', !fs.readFileSync(path.join(root,'apps/receiver/android/app/src/main/java/com/nexora/receiver/webrtc/WebRtcReceiver.kt'),'utf8').includes('screenshot')]
];
for (const [name, ok] of checks) console.log(`${ok?'PASS':'FAIL'} ${name}`);
if (checks.some(([,ok])=>!ok)) process.exit(1);
console.log(`Stage 3 verification: ${checks.length}/${checks.length} PASS`);
