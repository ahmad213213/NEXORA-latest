﻿param(
  [Parameter(Mandatory=$true)][ValidateSet('patch','restore')][string]$Mode,
  [Parameter(Mandatory=$true)][string]$Package,
  [Parameter(Mandatory=$true)][string]$InstallDir,
  [Parameter(Mandatory=$true)][int]$ProcessId,
  [string]$BackupZip = ''
)
# NEXORA local update: "patch" = back up the current version to a zip, then apply a patch zip;
# "restore" = replace the current version with a backup zip. The user's library, covers and settings
# live in the user data folder and are never touched.
$ErrorActionPreference = 'Stop'

# The installed app's exe is NEXORA.exe (installer build); older portable builds used NEXORA-Host.exe. Accept either.
function Find-AppExe([string]$Dir) {
  foreach ($n in @('NEXORA.exe','NEXORA-Host.exe')) {
    $p = Join-Path $Dir $n
    if (Test-Path -LiteralPath $p) { return $p }
  }
  return $null
}

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.IO.Compression.FileSystem

$title = if ($Mode -eq 'patch') { 'NEXORA Update' } else { 'NEXORA Restore' }
$form = New-Object System.Windows.Forms.Form
$form.Text = $title
$form.Width = 520; $form.Height = 190
$form.StartPosition = 'CenterScreen'
$form.TopMost = $true
$status = New-Object System.Windows.Forms.Label
$status.Left = 24; $status.Top = 24; $status.Width = 450; $status.Text = 'Getting ready…'
$bar = New-Object System.Windows.Forms.ProgressBar
$bar.Left = 24; $bar.Top = 62; $bar.Width = 450; $bar.Height = 24
$bar.Style = 'Continuous'; $bar.Minimum = 0; $bar.Maximum = 100
$detail = New-Object System.Windows.Forms.Label
$detail.Left = 24; $detail.Top = 98; $detail.Width = 450; $detail.Height = 40; $detail.Text = 'Waiting for NEXORA to close…'
$form.Controls.Add($status); $form.Controls.Add($bar); $form.Controls.Add($detail)
$form.Show()
[System.Windows.Forms.Application]::DoEvents()

function Set-Progress([int]$Value, [string]$StatusText, [string]$DetailText) {
  $bar.Value = [Math]::Max(0, [Math]::Min(100, $Value))
  $status.Text = $StatusText
  $detail.Text = $DetailText
  [System.Windows.Forms.Application]::DoEvents()
}
function Fail-Update([string]$Message) {
  Set-Progress 0 'Something went wrong' $Message
  [System.Windows.Forms.MessageBox]::Show($Message, $title, 'OK', 'Error') | Out-Null
  exit 1
}
function Test-Writable([string]$Dir) {
  try {
    $probe = Join-Path $Dir ('.nexora-write-test-' + [guid]::NewGuid().ToString('N'))
    [System.IO.File]::WriteAllText($probe, 'x')
    Remove-Item -LiteralPath $probe -Force
    return $true
  } catch { return $false }
}
function Test-Admin {
  $id = [Security.Principal.WindowsIdentity]::GetCurrent()
  return (New-Object Security.Principal.WindowsPrincipal($id)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}
# Refuses a zip whose entries would land outside the folder it is extracted to.
function Assert-SafeZip([string]$ZipPath, [string]$RootDir) {
  $zip = [System.IO.Compression.ZipFile]::OpenRead($ZipPath)
  try {
    $rootFull = [System.IO.Path]::GetFullPath($RootDir).TrimEnd('\') + '\'
    foreach ($entry in $zip.Entries) {
      $target = [System.IO.Path]::GetFullPath((Join-Path $RootDir $entry.FullName))
      if (-not $target.StartsWith($rootFull, [System.StringComparison]::OrdinalIgnoreCase)) { throw 'This zip file contains unsafe paths, so it was not used.' }
    }
  } finally { $zip.Dispose() }
}

$root = $null
$old = $null
try {
  Set-Progress 5 'Closing NEXORA' 'Waiting for NEXORA to close…'
  for ($i = 0; $i -lt 60; $i++) {
    try { Get-Process -Id $ProcessId -ErrorAction Stop | Out-Null; Start-Sleep -Milliseconds 500; [System.Windows.Forms.Application]::DoEvents() }
    catch { break }
  }
  $stillRunning = $false
  try { Get-Process -Id $ProcessId -ErrorAction Stop | Out-Null; $stillRunning = $true } catch { }
  if ($stillRunning) { throw 'NEXORA did not close in time. Please close it and try again.' }

  # Protected folder (for example Program Files): ask Windows for permission once, before anything is changed.
  if (-not (Test-Writable $InstallDir) -and -not (Test-Admin)) {
    $relaunch = @('-NoProfile','-ExecutionPolicy','Bypass','-File',$PSCommandPath,'-Mode',$Mode,'-Package',$Package,'-InstallDir',$InstallDir,'-ProcessId',$ProcessId)
    if ($BackupZip) { $relaunch += @('-BackupZip', $BackupZip) }
    Start-Process powershell.exe -Verb RunAs -ArgumentList $relaunch | Out-Null
    Set-Progress 100 'Windows permission needed' 'Please approve the Windows prompt to continue.'
    Start-Sleep -Seconds 2
    $root = $null
    exit 0
  }

  if ($Mode -eq 'patch') {
    if (-not $BackupZip) { throw 'No backup location was chosen.' }
    Set-Progress 15 'Saving a backup' 'Copying the current NEXORA version into your backup file…'
    $backupDir = Split-Path -Parent $BackupZip
    if ($backupDir) { New-Item -ItemType Directory -Force -Path $backupDir | Out-Null }
    if (Test-Path -LiteralPath $BackupZip) { Remove-Item -LiteralPath $BackupZip -Force }
    [System.IO.Compression.ZipFile]::CreateFromDirectory($InstallDir, $BackupZip, [System.IO.Compression.CompressionLevel]::Optimal, $false)
    if (-not (Test-Path -LiteralPath $BackupZip) -or ((Get-Item -LiteralPath $BackupZip).Length -lt 100)) { throw 'The backup could not be saved, so nothing was changed.' }
    Set-Progress 40 'Backup saved' 'Your current version is safe. Reading the patch…'
  }

  Set-Progress 45 'Checking the file' 'Making sure the zip is safe to use…'
  $root = Join-Path $env:TEMP ('NEXORA-local-' + [guid]::NewGuid().ToString('N'))
  New-Item -ItemType Directory -Force -Path $root | Out-Null
  Assert-SafeZip $Package $root
  Set-Progress 55 'Unpacking' 'Unpacking the zip file…'
  [System.IO.Compression.ZipFile]::ExtractToDirectory($Package, $root)

  $candidate = $null
  if (Find-AppExe $root) { $candidate = $root }
  else {
    foreach ($sub in @('NEXORA','NEXORA-Host')) {
      $subDir = Join-Path $root $sub
      if ((Test-Path -LiteralPath $subDir) -and (Find-AppExe $subDir)) { $candidate = $subDir; break }
    }
  }

  if ($Mode -eq 'restore' -and -not $candidate) { throw 'This zip is not a NEXORA backup (NEXORA.exe was not found inside).' }

  if ($candidate) {
    Set-Progress 70 'Installing' 'Replacing the NEXORA files…'
    $old = $InstallDir + '.old-' + (Get-Date -Format 'yyyyMMddHHmmss')
    Move-Item -LiteralPath $InstallDir -Destination $old -ErrorAction Stop
    Move-Item -LiteralPath $candidate -Destination $InstallDir -ErrorAction Stop
    if (-not (Find-AppExe $InstallDir)) { throw 'The installation could not be verified.' }
  } else {
    Set-Progress 70 'Installing' 'Applying the patch files…'
    Copy-Item -Path (Join-Path $root '*') -Destination $InstallDir -Recurse -Force -ErrorAction Stop
  }

  Set-Progress 92 'Finishing' 'Starting NEXORA…'
  $appExe = Find-AppExe $InstallDir
  if (-not $appExe) { throw 'NEXORA.exe was not found after the update.' }
  Start-Process -FilePath $appExe
  if ($old -and (Test-Path -LiteralPath $old)) { Remove-Item -LiteralPath $old -Recurse -Force -ErrorAction SilentlyContinue }
  Set-Progress 100 'All done' 'NEXORA is starting.'
  Start-Sleep -Seconds 2
} catch {
  $message = $_.Exception.Message
  try {
    if ($old -and (Test-Path -LiteralPath $old) -and -not (Test-Path -LiteralPath $InstallDir)) { Move-Item -LiteralPath $old -Destination $InstallDir -ErrorAction Stop }
  } catch { }
  if ($Mode -eq 'patch' -and $BackupZip -and (Test-Path -LiteralPath $BackupZip)) { $message += " Your backup is saved at: $BackupZip" }
  Fail-Update $message
} finally {
  if ($root) { Remove-Item -LiteralPath $root -Recurse -Force -ErrorAction SilentlyContinue }
  $form.Close()
  $form.Dispose()
}
