import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const batPath = path.join(root, 'make-installer.bat');
const packagePath = path.join(root, 'package.json');
if (!fs.existsSync(batPath)) {
  console.log('SKIP Installer BAT checks: make-installer.bat is intentionally omitted from the Phase 0 preview-only package.');
  console.log('These checks become active when the installer build phase adds the script back.');
  process.exit(0);
}
const bat = fs.readFileSync(batPath, 'utf8');
const pkg = JSON.parse(fs.readFileSync(packagePath, 'utf8'));
const tests = [
  ['pins electron-builder locally at 26.0.12', pkg.devDependencies?.['electron-builder'] === '26.0.12'],
  ['invokes local electron-builder with pnpm exec', /pnpm exec electron-builder --config/.test(bat)],
  ['does not invoke electron-builder through pnpm dlx', !/pnpm\s+dlx\s+electron-builder/i.test(bat)],
  ['checks StdUtils.nsh before NSIS packaging', bat.indexOf('call :check_stdutils') < bat.indexOf('pnpm exec electron-builder --config')],
  ['attempts one forced dependency repair', /pnpm install --force --no-frozen-lockfile/.test(bat)],
  ['does not delete the Installer output directory', !/rmdir\s+\/s\s+\/q\s+"%OUT%"/i.test(bat)],
  ['keeps temporary electron-builder config under installer-work', /set "CFG=%WORK%\\electron-builder\.yml"/.test(bat)],
  ['logs a clear failure if the NSIS include is absent', /:e_stdutils[\s\S]*StdUtils\.nsh is still missing/.test(bat)],
];
let failed = 0;
for (const [name, pass] of tests) {
  console.log(`${pass ? 'PASS' : 'FAIL'} ${name}`);
  if (!pass) failed++;
}
console.log(`\n${tests.length - failed}/${tests.length} installer script checks passed.`);
if (failed) process.exitCode = 1;
