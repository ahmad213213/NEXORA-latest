param([Parameter(Mandatory=$true)][string]$BuildDir,[Parameter(Mandatory=$true)][string]$OutputZip,[Parameter(Mandatory=$true)][string]$Version)
$ErrorActionPreference = 'Stop'
if (-not (Test-Path $BuildDir)) { throw 'Build directory missing' }
if (-not ((Test-Path (Join-Path $BuildDir 'NEXORA.exe')) -or (Test-Path (Join-Path $BuildDir 'NEXORA-Host.exe')))) { throw 'NEXORA.exe missing' }
$stage = Join-Path $env:TEMP ('NEXORA-portable-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Force -Path (Join-Path $stage 'NEXORA-Host') | Out-Null
Copy-Item -Path (Join-Path $BuildDir '*') -Destination (Join-Path $stage 'NEXORA-Host') -Recurse -Force
Set-Content -LiteralPath (Join-Path $stage 'NEXORA-Host/.nexora-version') -Value $Version -Encoding ASCII
New-Item -ItemType Directory -Force -Path (Join-Path $stage 'NEXORA-Host/vendor') | Out-Null
$ffmpeg = Join-Path $BuildDir 'vendor/ffmpeg.exe'
if (-not (Test-Path $ffmpeg)) { throw 'vendor/ffmpeg.exe missing from production build' }
Compress-Archive -Path (Join-Path $stage 'NEXORA-Host') -DestinationPath $OutputZip -Force
Remove-Item -LiteralPath $stage -Recurse -Force
Write-Host "Created $OutputZip for NEXORA $Version"
