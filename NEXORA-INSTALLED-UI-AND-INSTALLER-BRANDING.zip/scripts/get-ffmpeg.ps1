# NEXORA — download a pinned Windows ffmpeg.exe into vendor/
# Prefer gyan.dev essentials build (small, has the filters NEXORA needs).
$ErrorActionPreference = 'Stop'

$Root = Resolve-Path (Join-Path $PSScriptRoot '..')
# Prefer monorepo root when this script lives under NEXORA-Installers\scripts
if (Test-Path (Join-Path $Root 'package.json')) {
  $Repo = $Root
} elseif (Test-Path (Join-Path $Root '..\NEXORA-Integration-Final-Release\package.json')) {
  $Repo = Resolve-Path (Join-Path $Root '..\NEXORA-Integration-Final-Release')
} else {
  $Repo = $Root
}

$Vendor = Join-Path $Repo 'vendor'
$Target = Join-Path $Vendor 'ffmpeg.exe'
if (Test-Path $Target) {
  Write-Host "ffmpeg.exe already present: $Target"
  exit 0
}

New-Item -ItemType Directory -Force -Path $Vendor | Out-Null

# Pinned essentials build (update the URL when you intentionally bump FFmpeg)
$Url = 'https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip'
$Zip = Join-Path $env:TEMP ('nexora-ffmpeg-' + [guid]::NewGuid().ToString('N') + '.zip')
$Extract = Join-Path $env:TEMP ('nexora-ffmpeg-extract-' + [guid]::NewGuid().ToString('N'))

Write-Host "Downloading FFmpeg essentials..."
try {
  Invoke-WebRequest -Uri $Url -OutFile $Zip -UseBasicParsing
} catch {
  Write-Host "Download failed: $_"
  Write-Host "Put ffmpeg.exe into $Vendor manually and re-run."
  exit 1
}

try {
  Expand-Archive -LiteralPath $Zip -DestinationPath $Extract -Force
  $found = Get-ChildItem -Path $Extract -Recurse -Filter 'ffmpeg.exe' | Select-Object -First 1
  if (-not $found) { throw 'ffmpeg.exe not found inside the archive' }
  Copy-Item -LiteralPath $found.FullName -Destination $Target -Force
  Write-Host "Installed: $Target"
} finally {
  Remove-Item -LiteralPath $Zip -Force -ErrorAction SilentlyContinue
  Remove-Item -LiteralPath $Extract -Recurse -Force -ErrorAction SilentlyContinue
}
