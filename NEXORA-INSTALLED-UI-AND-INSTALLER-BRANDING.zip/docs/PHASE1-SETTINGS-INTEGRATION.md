# Phase 1 — Settings integration

## Scope

This change integrates the settings feature into the **Electron host source tree** (`apps/host`) rather than the standalone UI prototype. It keeps the existing Desktop/Console UI and updater screens, while making app-owned preferences use one persisted configuration source.

## What is implemented

- **General:** PC display name; default launch surface (Desktop or Console on next app start); Windows sign-in startup preference in a packaged Windows build.
- **Appearance:** Midnight, Obsidian, and Earth Horizon themes; six accent colors; reduced-motion preference. These are applied live through document-root CSS tokens so common elements stay consistent across both UI modes.
- **Streaming:** host mode and the four existing quality presets are persisted in `config.json`. Derived video width, height, FPS, and bitrate are resolved by the existing quality policy. The UI explicitly avoids promising that settings reconfigure an already-running encoder; that belongs to the capture/streaming integration phase.
- **Network:** shows the actual paired receiver count and links to the existing Remote Play page. It does not introduce fake network switches for services that are not connected.
- **Updates:** retains the existing signed updater configuration/check/patch/restore functions.
- **Privacy & Security:** export/import of settings JSON and a reset-to-defaults action.

## Storage and schema

The host config schema is version 3 and is saved to `app.getPath('userData')/config.json`. Existing version 2 files are accepted and normalized with safe defaults for the new fields. A subsequent settings save writes the current schema.

The new fields are:

- `profileName` — validated, trimmed, and limited to 32 characters.
- `launchMode` — `desktop` or `console`; applies on the next startup.
- `appearance.theme` — `midnight`, `obsidian`, or `earth`.
- `appearance.accent` — `cyan`, `blue`, `violet`, `amber`, `emerald`, or `rose`.
- `appearance.reducedMotion` — boolean.

Partial config changes are merged against the current saved config, including deep merges for `appearance` and `streaming`. Invalid enum values and wrongly typed boolean/nested values are rejected rather than silently resetting other preferences. Writes are serialized, use unique temporary names, and atomically rename into place. If a write fails, the in-memory config is not replaced by an unpersisted value.

## Electron boundary and safety

Settings I/O is owned by the main process. The renderer uses the existing `window.nexora` context-isolated bridge. Each added IPC handler checks the existing trusted-renderer/lifecycle guard:

- `settings:capabilities`
- `settings:export`
- `settings:import`
- `settings:reset`

Settings imports are limited to 512 KiB, parsed as JSON, and validated/normalized before saving. Import accepts the NEXORA export envelope (`schemaVersion: 1`) and legacy/current raw config objects (version 2 or 3). Invalid JSON and unsupported formats return explicit errors without replacing existing settings.

Export includes app-owned `config.json` preferences only. It deliberately excludes the separate AI provider credentials, pairing identities, library data, and update signing material. Reset/import likewise do not overwrite those separately stored systems; reset does restore the config-owned preferences to defaults. The Windows startup toggle is only enabled for a packaged Windows build; the main process applies it with Electron's login-item API and reports application warnings to the UI.

## Verification performed

- `apps/host/test/settings-phase1.test.mjs`: **5/5 passed**.
- Combined baseline + Phase 1 tests (`foundation.test.mjs` + `settings-phase1.test.mjs`): **17/17 passed**. Tests cover version-2 normalization, bounds/enum validation, nested partial-update preservation, strict patch validation, concurrent saves, reload from disk, corrupt-config quarantine, and IPC/renderer wiring.
- `node --check apps/host/src/ui/app.js`: passed.
- TypeScript transpilation/syntax diagnostics for `config.ts`, `main.ts`, and `preload.cts`: zero syntax diagnostics.
- CSS parser: **317 top-level rules, zero parser errors**.
- Existing project static verifiers: foundation **7/7**, final recheck **16/16**, final release audit **9/9** plus 184 source/docs files scanned, Part 8 static verification **10/10**, integration Stage 5 verification **12/12**.

## Verification limitation

A complete TypeScript project typecheck, `pnpm build`, full existing test suite, packaged Windows build, and an actual Electron restart/startup test were **not run in this environment**. The archive has no installed dependencies and Corepack could not download the pinned pnpm version because the npm registry DNS request failed (`EAI_AGAIN registry.npmjs.org`). Static checks and config-runtime tests pass, but those results are not a substitute for compiling/launching the packaged Windows application.

## Next verification on a development machine

From the repository root with Node 22 and the pinned pnpm installed:

```powershell
pnpm install
pnpm test
pnpm typecheck
pnpm build
pnpm --filter @nexora/host start
```

Then change the PC name and appearance, restart NEXORA and confirm the values persist; switch to Console Mode and confirm the same theme/accent/name are present; test export/import/reset; and in the packaged Windows build, enable startup and confirm Windows actually launches NEXORA at sign-in. Do not consider Phase 1 release-verified until those packaged-runtime checks pass.
