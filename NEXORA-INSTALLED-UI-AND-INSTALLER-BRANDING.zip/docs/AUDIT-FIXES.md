# Audit fixes (v1.2 ORBIT build)

## Fixed
| Problem | Fix |
|---|---|
| Games listed in the wrong order (ISO date text turned into NaN) | dates are parsed before sorting (3 places) |
| Update check said "up to date" when the update could not be verified | clear messages: not set up / could not be verified / no connection |
| Update settings could only come from an environment variable; the update key was a placeholder | `update-url.txt` and `update-public-key.txt` in `<app data>/update/` (env variables still win) |
| No backup / restore | Settings: **Update from a file** (asks where to save a backup zip first, then applies the patch) and **Restore a backup**; progress window; automatic roll-back if anything fails |
| Updater script ran from inside the folder it replaces; `$Pid` is a read-only PowerShell name | script is copied to the temp folder first; parameter renamed `ProcessId` |
| Updater could be started from a development run | blocked unless the app is installed |
| A new cover could be hidden by an older cover of another file type; old screenshots stayed behind | old files are removed when a new one is saved |
| Console Mode: Esc did nothing; long text cut mid-line | Esc leaves Console Mode; text ends with "…" |
| CPU / GPU / RAM / network numbers were typed into the page | real CPU and RAM from the PC, rings follow the value; GPU shows "Not available"; fake network/audio rows removed; duplicate panel removed |
| "AK" avatar, decorative volume slider and icons | removed / replaced |
| Hero picture loaded from the internet (Unsplash) | local `assets/hero-default.svg`; internet image source removed from the security policy |
| Text as small as 7 px | nothing below 11 px |
| Plain browser pop-ups | styled confirm window (remove game, update) |
| Close (×) on System Usage / Game Info hid them for good; × on the Add Game window broke reopening | those buttons removed; generic hide handler removed |
| Window could not shrink, small-screen layouts never used | opens at 1080p (or the biggest the screen allows), minimum 760 x 560 |
| `filter:blur` in Console Mode CSS (GPU cost) | removed |
| Two out-of-date checks (ABR cooldown test, `verify-part4`) | updated to the current code |
| `frame-ancestors` in a meta tag (ignored, logged an error) | removed |
| Orbit docs said “3 best matches” while code shows 4 | README, `orbit-search.ts` comment, and `ORBIT-INTEGRATION.md` aligned to **4** (`ORBIT_MAX_OPTIONS = 4`) |
| Empty leftover `apps/receiver/src/` tree (real code is under `android/`) | removed |
| Controls “View layout” only showed a toast | expands an in-page list of control labels/types/actions; click again to hide |
| PIN / Devices copy implied full pairing from the form alone | wording clarified: format check in UI; full pairing is the connection service + receiver |

## How to set up online updates (optional)
Create `update-url.txt` (one line, https address of the signed manifest) and `update-public-key.txt` (one line, the release public key, base64) in the `update` folder inside the NEXORA app data folder. Without them, "Check for updates" says online updates are not set up and **Update from a file** still works.

## Not verified
No Windows / Electron run, no PowerShell here: `apply-local-update.ps1` and `apply-update.ps1` were reviewed and pattern-tested only. Live store answers (Add Game search) were not tested (no internet in the build environment).
