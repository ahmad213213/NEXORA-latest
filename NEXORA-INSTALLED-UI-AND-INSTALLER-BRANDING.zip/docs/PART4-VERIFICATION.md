# Part 4 Verification

## Required checks

- [x] FFmpeg command construction is deterministic and bounded.
- [x] Desktop capture supports ddagrab/gdigrab.
- [x] H.264 encoder selection probes real encoders and falls back to x264.
- [x] Video uses low-latency H.264 settings and one-second GOP.
- [x] Audio is optional and uses DirectShow → Opus 48 kHz stereo.
- [x] Audio failure is bounded and does not automatically kill video.
- [x] Capture start is single-flight.
- [x] Generation ownership prevents stale process callbacks from touching a newer session.
- [x] Stop is idempotent and closes processes/sockets.
- [x] Quality changes are bounded and restart video only.
- [x] Adaptive bitrate is rate-limited and bounded.
- [x] Part 4 remains independent from signaling/WebRTC.

## Environment limitation

Static verification and source-level checks can run here. Real Windows desktop capture, DirectShow device capture, hardware encoders, Electron GPU behavior, and Android runtime behavior must still be validated on the target Windows/Android machines.
