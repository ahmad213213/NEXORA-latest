> Scope note: this is retained as technical reference for the later Windows build phase. The Phase 0 preview-only ZIP intentionally does not include `make-installer.bat`.

# NEXORA Phase 1 — installer build fix

This design note describes a proposed fix for the previous `make-installer.bat`. The batch file is intentionally omitted from this Phase 0 preview-only delivery and must be reintroduced and tested in the later build phase.

## Root cause indicated by the supplied log

The uploaded log ran `pnpm dlx electron-builder@26.0.12`. NSIS then failed to include `StdUtils.nsh` from the temporary pnpm dlx directory. The failure is in installer packaging, after the workspace TypeScript build succeeded.

The new script uses the `electron-builder` devDependency pinned at `26.0.12` and invokes it via `corepack pnpm exec electron-builder`. It checks that the local `app-builder-lib/templates/nsis/include/StdUtils.nsh` file is available before running NSIS. If missing, it tries one forced pnpm dependency reinstall, checks again, and stops with an explicit error if the file is still missing.

The script also moves its generated electron-builder YAML under `installer-work`, preserves a project `build` resources folder explicitly, cleans only its own staging app directory, preserves the existing `Installer` directory, and backs up an existing `NEXORA-Setup-1.2.0-x64.exe` before attempting a replacement.

## Run it

1. Extract the ZIP into a **new directory**.
2. In the later build phase, place the reviewed `make-installer.bat` beside `package.json`.
3. Run that file from the new directory.
4. If it fails, provide the newly generated `installer-build.log`.

A previous build log is not proof that this revision was run. The new log should say it uses project-local electron-builder and must not contain an executed `pnpm dlx electron-builder` command.

## Verification boundary

Static review confirms the updated script contains no `pnpm dlx electron-builder` invocation, pins the local dependency, performs the NSIS-include preflight, and does not delete the `Installer` folder. This environment cannot run the final Windows NSIS build, so success is not claimed until the EXE is created by the updated script.
