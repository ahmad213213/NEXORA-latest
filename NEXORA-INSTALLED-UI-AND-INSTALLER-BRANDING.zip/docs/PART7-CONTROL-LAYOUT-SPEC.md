# Part 7 — Control Layout & Advanced Gameplay

Part 7 introduces persistent, editable controller layouts shared by Host and Receiver.

## Contract
- Normalized coordinates: x/y/width/height in 0..1.
- Maximum 24 controls per layout.
- Stable IDs and bounded labels/actions.
- Opacity is normalized to 0..1.
- Layout version is explicit (`1`).
- Supported genres: custom, action, racing, shooter, sports, rpg.

## Behavior
- Six genre/default layouts can be created and persisted.
- Layouts are atomically saved in Host userData.
- Invalid layouts are rejected before persistence.
- Duplicate IDs, out-of-bounds controls and oversized layouts are rejected.
- Host exposes narrow, sender-checked IPC for list/save/remove.
- Receiver's overlay is designed to consume the same normalized layout contract rather than owning hardcoded positions.
- Runtime touch input continues through Part 6's sequenced dispatcher.

## UX direction
The gameplay editor is intended to support drag/move, resize, opacity, labels, action assignment, z-order and per-game selection in the next UI integration pass. The data contract is deliberately ready for those operations without embedding renderer logic in the Host main process.

## Editor prototype
`apps/host/src/ui/layout/layout-editor.js` provides a lightweight DOM editor model with no render loop and no blur-heavy effects. It is intentionally modular so the premium-glass dashboard can integrate it without making the main dashboard re-render continuously.
