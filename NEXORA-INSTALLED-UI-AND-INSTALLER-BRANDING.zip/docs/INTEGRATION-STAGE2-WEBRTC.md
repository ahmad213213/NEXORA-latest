# NEXORA Integration Stage 2 — WebRTC

This stage introduces the real WebRTC endpoint boundary.

## Host
`WebRtcPeerSession` owns SDP/ICE sequencing, validates SDP size/type, binds asynchronous operations to a session generation, and exposes a transport adapter. The adapter is intentionally separate from signaling and media capture so a native/WebRTC implementation can be selected per platform.

## Android
The receiver now includes the pinned `org.webrtc:google-webrtc` AAR and a real `PeerConnectionFactory` / Unified Plan peer connection. Remote video/audio tracks are surfaced to the gameplay layer; local ICE is emitted to the signaling layer through callbacks.

## Security
- Signaling transports only SDP/ICE/session control messages.
- Media is never sent to the signaling server.
- SDP is capped at 256 KiB.
- ICE candidate strings are bounded.
- Host asynchronous WebRTC operations use generation ownership.
- Closing a session invalidates pending operations.

## Verification limitation
The Linux build environment cannot prove Android Gradle resolution, Windows native WebRTC media capture, or a real WAN WebRTC call. Those require Windows/Android devices and a reachable signaling/STUN/TURN environment. This stage does not claim those runtime checks passed.
