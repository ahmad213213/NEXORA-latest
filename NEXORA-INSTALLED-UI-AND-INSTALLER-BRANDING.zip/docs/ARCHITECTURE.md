# NEXORA Rebuild Architecture — Part 1

## Boundaries

```text
apps/host             Windows desktop shell and orchestration
apps/receiver/android Android receiver application
packages/shared       Protocol/types only; no Electron/Android dependencies
```

## Host lifecycle

```text
created -> starting -> running -> stopping -> stopped
```

Startup acquires the Electron single-instance lock before creating windows.
Shutdown is idempotent and waits for registered cleanup before `app.exit()`.

## IPC security

Renderer access is exposed only through `contextBridge` methods. Main-process
handlers verify the sender is the current trusted main window and reject requests
while the host is stopping/stopped. Raw `ipcRenderer` is never exposed.

## Configuration

Configuration is validated and normalized before being returned or persisted.
Writes use a temporary file and atomic rename. Invalid persisted data is quarantined
instead of silently replacing it with an untraceable reset.

## Protocol

The shared protocol has an explicit namespace and version. Messages use a validated
envelope with a session id, monotonically interpreted sequence number, timestamp,
and typed message name. Streaming media is deliberately outside this signaling contract.


## Part 4 streaming boundary

```text
Windows capture/audio
        │
        ▼
   CaptureEngine ──► localhost RTP ──► MediaSink ──► Part 5 WebRTC
        │
        ├── H.264 encoder selection/fallback
        ├── optional Opus audio
        ├── generation-owned lifecycle
        └── bounded quality/bitrate changes
```

The streaming engine does not know about signaling, PIN pairing, ICE, TURN, or Android. This prevents media concerns from leaking into the signaling layer.

## Part 5 networking/security boundary

```text
Host identity + paired-device store
              │
              ▼
       SignalingClient
              │
        signed control
              │
              ▼
       Signaling service
          /          \
       SDP/ICE       session state
          \          /
              ▼
       WebRTC peer connection
              │
        video/audio/input
              │
              ▼
          Receiver
```

The signaling service is not a media endpoint. Security checks are kept in the host networking layer and a transport-neutral `SignalingCore` so a future server transport cannot bypass the same authorization and signature rules.
