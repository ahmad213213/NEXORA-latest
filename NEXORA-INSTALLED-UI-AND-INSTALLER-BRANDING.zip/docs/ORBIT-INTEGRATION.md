# NEXORA ORBIT integration (Add Game)

Game info is now found by **NEXORA ORBIT** (Steam, GOG, EGData/Epic, itchDB, optional RAWG) instead of the Steam-only provider.

## Flow
1. **Add Game** -> pick the `.exe` (unchanged). Nothing is saved yet.
2. The *Add Game* window opens with the name taken from the file name. The user checks or edits it and presses **Add Game**; the window shows "Searching…" (the word ORBIT is never shown to the user).
3. Typing only clears old results; Add Game (or Enter) starts the search. Only one network search runs at a time and outdated queries are skipped (latest wins). Names under 2 letters do not search.
4. When the search is finished the **4 best matches** appear (thumbnail, stores, match %). The main process remembers exactly those 4.
5. The user picks one. ORBIT then loads the rest: full details, the best-quality cover, up to 5 screenshots. Progress is shown in the window. Then the game is saved atomically (library.json, cover, screenshots).

## Files
| File | Role |
|---|---|
| `src/orbit/orbit-lib.mjs` | ORBIT CLI v2.2.0 library, unchanged except `downloadImage` is exported |
| `src/orbit/orbit-search.ts` | background search queue, top-4 sessions, cache, details/cover/screenshot loading |
| `src/orbit/orbit-keys.ts` | optional key files + aliases |
| `src/library-controller.ts` | `beginAdd`, `commitOrbit`, `discardAdd` |
| `src/library-store.ts` | `saveScreenshots`, `removeScreenshots`, larger cover limit for ORBIT covers |
| `src/main.ts`, `src/preload.ts` | IPC: `library:begin-add`, `orbit:search`, `orbit:choose`, `orbit:cancel`, event `orbit:progress` |
| `src/ui/*` | new `orbitModal` |

## Safety rules kept
- All IPC checks `isTrustedSender`; ids and numbers are validated; the renderer sends only `(pendingId, text, requestId, index)`, never a URL or path.
- Only https URLs that came from the store APIs are downloaded; image types are checked; sizes are capped (cover 12 MB, screenshot 8 MB, thumbnail 1.5 MB).
- A game is only added after the user picks one of the 4 shown matches (a stale `requestId` is rejected).
- Search results from failing providers are never cached.
- The old Steam-only flow (`library:add-dialog`) is still there as a fallback.

## Optional keys / aliases (same file names as the ORBIT CLI)
Put them in the app data folder, sub-folder `orbit` (e.g. `%APPDATA%\<app name>\orbit\`):
`steamgriddb-key.txt`, `igdb-key.txt` (line 1 Client ID, line 2 Secret), `rawg-key.txt`, `aliases.json`.

## Data added to a game
`metadata.screenshots[]`, `shortDescription`, `developers`, `publishers`, `orbit {fetchedAt, cover size/source, notices}`. `metadata.cover` is now optional (a game without any cover gets the placeholder). UI URLs: `nexora-cover://<id>` (cover), `nexora-cover://<id>/shot/<n>` (screenshots).

## Verification status
- `pnpm test:orbit`: 10 service tests (latest-wins queue, caching rules, stale picks, screenshot failures, ...) + 5 wiring/security checks.
- Library save/remove path and the modal were also run end to end in a scratch setup (stubbed Electron, headless Chromium with a mocked bridge).
- **Not verified:** live answers of the stores from this build environment (no internet), and a real Electron/Windows run. Run `pnpm install && pnpm build && pnpm test`, then add a game on your PC.
- Two tests fail in the original project too and are unrelated: `Part 2 UI has deterministic performance guards` (console-mode CSS uses `filter:blur`) and `ABR cooldown`.
