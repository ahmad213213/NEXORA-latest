# Phase 1-related checks — UI preview package

The checks in this package cover only the intended browser prototype:
- JavaScript syntax checks for the UI app and background rotator.
- No preloaded game tile/card records in the Dashboard, Library or Console view.
- Four wallpaper assets exist locally.
- Background rotation order is tested in Node with a simulated localStorage store.
- `PREVIEW.bat` points to the built prototype, not the legacy live renderer.
- Only `PREVIEW.bat` exists as a batch file.

The package has not been validated as a complete Phase 1 Electron integration; live Electron launch, native settings persistence across Windows restarts, full workspace typecheck/build, and NSIS installer are outside these preview checks.
