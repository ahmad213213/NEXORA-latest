package com.nexora.receiver.gameplay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View
import com.nexora.receiver.input.InputDispatcher
import com.nexora.receiver.input.InputEvent
import kotlin.math.min

class ControlOverlayView(context: Context, private val dispatcher: InputDispatcher, private var layout: ControlLayout) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val active = HashSet<String>()
    private var sequence = 0L
    init { setWillNotDraw(false) }
    fun setLayout(next: ControlLayout) { layout = next; invalidate() }
    private fun rect(c: ControlLayoutItem) = floatArrayOf(c.x*width, c.y*height, (c.x+c.width)*width, (c.y+c.height)*height)
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        layout.controls.sortedBy { it.z }.forEach { c ->
            val r=rect(c); val cx=(r[0]+r[2])/2; val cy=(r[1]+r[3])/2
            paint.alpha=(c.opacity.coerceIn(0f,1f)*255).toInt(); paint.style=Paint.Style.STROKE; paint.strokeWidth=3f
            val radius=min(r[2]-r[0],r[3]-r[1])*.42f
            if(c.type=="button" || c.type=="trigger") canvas.drawRoundRect(r[0],r[1],r[2],r[3],radius,radius,paint) else canvas.drawCircle(cx,cy,radius,paint)
            paint.style=Paint.Style.FILL; paint.textAlign=Paint.Align.CENTER; paint.textSize=22f; canvas.drawText(c.label,cx,cy+8f,paint)
        }
        paint.alpha=255
    }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if(e.action!=MotionEvent.ACTION_DOWN && e.action!=MotionEvent.ACTION_UP) return true
        val hit=layout.controls.asSequence().sortedByDescending { it.z }.firstOrNull { c -> val r=rect(c); e.x>=r[0]&&e.x<=r[2]&&e.y>=r[1]&&e.y<=r[3] } ?: return true
        val down=e.action==MotionEvent.ACTION_DOWN; if(down) active.add(hit.id) else active.remove(hit.id)
        dispatcher.dispatch(InputEvent("gamepad-button",if(down)"down"else"up",hit.action,sequence=++sequence,timestamp=System.currentTimeMillis()))
        invalidate(); return true
    }
}
