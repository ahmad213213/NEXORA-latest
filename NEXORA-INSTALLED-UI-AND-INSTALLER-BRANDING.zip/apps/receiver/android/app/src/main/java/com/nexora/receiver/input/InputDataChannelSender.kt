package com.nexora.receiver.input

import org.json.JSONObject
import org.webrtc.DataChannel
import java.nio.ByteBuffer
import java.util.ArrayDeque

/** Ordered, bounded input sender. Events are queued briefly until the WebRTC channel opens. */
class InputDataChannelSender(private val channel: DataChannel) : DataChannel.Observer {
    private val queue = ArrayDeque<InputEvent>()
    private val maxQueued = 32

    init { channel.registerObserver(this); flush() }

    fun send(event: InputEvent) {
        if (channel.state() == DataChannel.State.OPEN) {
            write(event)
        } else if (queue.size < maxQueued) {
            queue.addLast(event)
        }
    }

    private fun flush() {
        if (channel.state() != DataChannel.State.OPEN) return
        while (queue.isNotEmpty()) write(queue.removeFirst())
    }

    private fun write(event: InputEvent) {
        val obj = JSONObject().apply {
            put("v", 1)
            put("type", "input")
            put("event", JSONObject().apply {
                put("kind", event.kind)
                put("action", event.action)
                put("code", event.code)
                event.value?.let { put("value", it) }
                event.x?.let { put("x", it) }
                event.y?.let { put("y", it) }
                put("sequence", event.sequence)
                put("timestamp", event.timestamp)
            })
        }
        val bytes = obj.toString().toByteArray(Charsets.UTF_8)
        if (bytes.size <= 8192) channel.send(DataChannel.Buffer(ByteBuffer.wrap(bytes), false))
    }

    override fun onStateChange() = flush()
    override fun onMessage(buffer: DataChannel.Buffer?) {}
    override fun onBufferedAmountChange(previousAmount: Long) {}
}
