package com.nexora.receiver.connection

/** Typed control-plane messages. Media never travels through this layer. */
sealed interface SignalingMessage {
    data class Offer(val sessionId: String, val sdp: String): SignalingMessage
    data class Answer(val sessionId: String, val sdp: String): SignalingMessage
    data class Ice(val sessionId: String, val candidate: String, val sdpMid: String?, val sdpMLineIndex: Int?): SignalingMessage
    data class Close(val sessionId: String): SignalingMessage
}

object SignalingMessageValidator {
    private const val MAX_SDP = 256 * 1024
    private const val MAX_CANDIDATE = 8192
    fun validate(message: SignalingMessage): Boolean = when (message) {
        is SignalingMessage.Offer -> validSession(message.sessionId) && validSdp(message.sdp)
        is SignalingMessage.Answer -> validSession(message.sessionId) && validSdp(message.sdp)
        is SignalingMessage.Ice -> validSession(message.sessionId) && message.candidate.length in 1..MAX_CANDIDATE
        is SignalingMessage.Close -> validSession(message.sessionId)
    }
    private fun validSession(id: String) = Regex("^[A-Za-z0-9_-]{8,128}$").matches(id)
    private fun validSdp(sdp: String) = sdp.length <= MAX_SDP && sdp.contains("v=0")
}
