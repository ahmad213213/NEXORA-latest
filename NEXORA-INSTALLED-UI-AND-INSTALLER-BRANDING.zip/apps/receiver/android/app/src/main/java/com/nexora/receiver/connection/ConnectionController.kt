package com.nexora.receiver.connection

import com.nexora.receiver.webrtc.WebRtcReceiver
import org.webrtc.IceCandidate
import org.webrtc.PeerConnection

/** Receiver-side orchestration. The signaling transport is injected by the app/network layer. */
class ConnectionController(private val rtc: WebRtcReceiver) {
    var sessionId: String? = null
        private set
    var state: State = State.IDLE
        private set

    enum class State { IDLE, NEGOTIATING, CONNECTED, DISCONNECTED, CLOSED }

    fun acceptOffer(session: String, sdp: String, sendAnswer: (String, String) -> Unit) {
        require(SignalingMessageValidator.validate(SignalingMessage.Offer(session, sdp)))
        sessionId = session
        state = State.NEGOTIATING
        rtc.setRemoteOffer(sdp) { answer ->
            sendAnswer(session, answer)
        }
    }

    fun acceptAnswer(session: String, sdp: String) {
        require(sessionId == session)
        require(SignalingMessageValidator.validate(SignalingMessage.Answer(session, sdp)))
        rtc.setRemoteAnswer(sdp)
    }

    fun addIce(session: String, candidate: IceCandidate) {
        require(sessionId == session)
        rtc.addIce(candidate)
    }

    fun onPeerState(peerState: PeerConnection.PeerConnectionState) {
        state = when (peerState) {
            PeerConnection.PeerConnectionState.CONNECTED -> State.CONNECTED
            PeerConnection.PeerConnectionState.DISCONNECTED,
            PeerConnection.PeerConnectionState.FAILED -> State.DISCONNECTED
            PeerConnection.PeerConnectionState.CLOSED -> State.CLOSED
            else -> State.NEGOTIATING
        }
    }

    fun close() {
        state = State.CLOSED
        sessionId = null
        rtc.close()
    }
}
