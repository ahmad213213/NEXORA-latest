package com.nexora.receiver.webrtc

import android.content.Context
import org.webrtc.AudioTrack
import org.webrtc.IceCandidate
import org.webrtc.MediaStream
import org.webrtc.PeerConnection
import org.webrtc.PeerConnectionFactory
import org.webrtc.SessionDescription
import org.webrtc.SurfaceViewRenderer
import org.webrtc.VideoTrack

/** Real Android WebRTC endpoint. Signaling is injected; no signaling transport is owned here. */
class WebRtcReceiver(
    context: Context,
    private val onLocalIce: (IceCandidate) -> Unit,
    private val onState: (PeerConnection.PeerConnectionState) -> Unit,
    private val onRemoteAudio: (AudioTrack) -> Unit = {},
    private val onRemoteVideo: (VideoTrack) -> Unit = {},
    private val onInputChannel: (org.webrtc.DataChannel) -> Unit = {}
) {
    private val factory: PeerConnectionFactory
    private val peer: PeerConnection

    init {
        initializeFactory(context)
        factory = requireNotNull(PeerConnectionFactory.builder().createPeerConnectionFactory())
        val config = PeerConnection.RTCConfiguration(emptyList()).apply {
            sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
        }
        peer = requireNotNull(factory.createPeerConnection(config, object : PeerConnection.Observer {
            override fun onIceCandidate(candidate: IceCandidate) = onLocalIce(candidate)
            override fun onConnectionChange(state: PeerConnection.PeerConnectionState) = onState(state)
            override fun onTrack(transceiver: PeerConnection.RtpTransceiver?) {
                val track = transceiver?.receiver?.track()
                when (track) {
                    is VideoTrack -> { track.setEnabled(true); onRemoteVideo(track) }
                    is AudioTrack -> { track.setEnabled(true); onRemoteAudio(track) }
                }
            }
            override fun onSignalingChange(p0: PeerConnection.SignalingState?) {}
            override fun onIceConnectionChange(p0: PeerConnection.IceConnectionState?) {}
            override fun onIceConnectionReceivingChange(p0: Boolean) {}
            override fun onIceGatheringChange(p0: PeerConnection.IceGatheringState?) {}
            override fun onIceCandidatesRemoved(p0: Array<out IceCandidate>?) {}
            override fun onAddStream(p0: MediaStream?) {}
            override fun onRemoveStream(p0: MediaStream?) {}
            override fun onDataChannel(p0: org.webrtc.DataChannel?) { if (p0 != null) onInputChannel(p0) }
            override fun onRenegotiationNeeded() {}
            override fun onAddTrack(p0: org.webrtc.RtpReceiver?, p1: Array<out MediaStream>?) {}
        }))
    }

    fun createInputDataChannel(): org.webrtc.DataChannel = peer.createDataChannel("nexora-input-v1", org.webrtc.DataChannel.Init().apply { ordered = true; maxRetransmits = -1 })

    fun setRemoteOffer(sdp: String, onAnswer: (String) -> Unit) {
        peer.setRemoteDescription(object : SimpleSdpObserver() {
            override fun onSetSuccess() {
                peer.createAnswer(object : SimpleSdpObserver() {
                    override fun onCreateSuccess(answer: SessionDescription) {
                        peer.setLocalDescription(object : SimpleSdpObserver() {
                            override fun onSetSuccess() { onAnswer(answer.description) }
                        }, answer)
                    }
                }, MediaConstraints())
            }
        }, SessionDescription(SessionDescription.Type.OFFER, sdp))
    }

    fun setRemoteAnswer(sdp: String) = peer.setRemoteDescription(SimpleSdpObserver(), SessionDescription(SessionDescription.Type.ANSWER, sdp))

    fun addIce(candidate: IceCandidate) = peer.addIceCandidate(candidate)

    fun render(video: VideoTrack, renderer: SurfaceViewRenderer) {
        video.addSink(renderer)
    }

    fun close() {
        peer.close()
        factory.dispose()
    }

    private class MediaConstraints : org.webrtc.MediaConstraints()

    companion object {
        @Volatile private var initialized = false
        private fun initializeFactory(context: Context) {
            if (initialized) return
            synchronized(this) {
                if (initialized) return
                PeerConnectionFactory.initialize(
                    PeerConnectionFactory.InitializationOptions.builder(context.applicationContext).createInitializationOptions()
                )
                initialized = true
            }
        }
    }
    private open class SimpleSdpObserver : org.webrtc.SdpObserver {
        override fun onCreateSuccess(p0: SessionDescription?) {}
        override fun onSetSuccess() {}
        override fun onCreateFailure(p0: String?) {}
        override fun onSetFailure(p0: String?) {}
    }
}
