import { promises as fs } from 'node:fs';
import path from 'node:path';
import {
  createDefaultKeyMap,
  listBuiltinKeyMaps,
  normalizeKeyMapProfile,
  validateKeyMapProfile,
  type KeyMapProfile
} from '@nexora/shared';
import type { MapperDirection } from './key-mapper.js';

export type KeyMapMode = 'off' | 'keyboard' | 'controller';

export interface KeyMapState {
  /**
   * controller = keyboard/touch becomes virtual Xbox pad (Cricket 22 etc.)
   * keyboard   = pad becomes keyboard keys
   * off        = no conversion
   */
  mode: KeyMapMode;
  activeProfileId: string;
  profiles: KeyMapProfile[];
}

const DEFAULT_STATE = (): KeyMapState => ({
  mode: 'controller',
  activeProfileId: 'keymap_sports',
  profiles: listBuiltinKeyMaps()
});

export class KeyMapStore {
  private state: KeyMapState = DEFAULT_STATE();

  constructor(private readonly file: string) {}

  async load(): Promise<KeyMapState> {
    try {
      const raw = JSON.parse(await fs.readFile(this.file, 'utf8')) as Partial<KeyMapState>;
      const builtins = listBuiltinKeyMaps();
      const custom = Array.isArray(raw.profiles)
        ? raw.profiles.filter(validateKeyMapProfile).map(normalizeKeyMapProfile)
        : [];
      const byId = new Map<string, KeyMapProfile>();
      for (const p of builtins) byId.set(p.id, p);
      for (const p of custom) byId.set(p.id, normalizeKeyMapProfile(p));
      const mode: KeyMapMode =
        raw.mode === 'off' ? 'off' : raw.mode === 'keyboard' ? 'keyboard' : 'controller';
      this.state = {
        mode,
        activeProfileId: typeof raw.activeProfileId === 'string' ? raw.activeProfileId : 'keymap_sports',
        profiles: [...byId.values()]
      };
      if (!this.state.profiles.some(p => p.id === this.state.activeProfileId)) {
        this.state.activeProfileId = 'keymap_sports';
      }
    } catch {
      this.state = DEFAULT_STATE();
      await this.save();
    }
    return this.snapshot();
  }

  snapshot(): KeyMapState {
    return {
      mode: this.state.mode,
      activeProfileId: this.state.activeProfileId,
      profiles: this.state.profiles.map(p => structuredClone(p))
    };
  }

  getActiveProfile(): KeyMapProfile | null {
    if (this.state.mode === 'off') return null;
    return this.state.profiles.find(p => p.id === this.state.activeProfileId) ?? null;
  }

  getDirection(): MapperDirection {
    if (this.state.mode === 'keyboard') return 'to-keyboard';
    if (this.state.mode === 'controller') return 'to-controller';
    return 'off';
  }

  async setMode(mode: KeyMapMode): Promise<KeyMapState> {
    this.state.mode = mode === 'off' ? 'off' : mode === 'keyboard' ? 'keyboard' : 'controller';
    await this.save();
    return this.snapshot();
  }

  async setActiveProfile(id: string): Promise<KeyMapState> {
    if (!this.state.profiles.some(p => p.id === id)) throw new Error('Unknown profile');
    this.state.activeProfileId = id;
    await this.save();
    return this.snapshot();
  }

  async upsertProfile(profile: unknown): Promise<KeyMapState> {
    if (!validateKeyMapProfile(profile)) throw new Error('Invalid key map profile');
    const n = normalizeKeyMapProfile(profile);
    const i = this.state.profiles.findIndex(p => p.id === n.id);
    if (i >= 0) this.state.profiles[i] = n;
    else this.state.profiles.push(n);
    await this.save();
    return this.snapshot();
  }

  async resetProfile(id: string): Promise<KeyMapState> {
    const genre = id.replace(/^keymap_/, '') as KeyMapProfile['genre'];
    const built = createDefaultKeyMap(
      ['universal', 'action', 'racing', 'shooter', 'sports', 'rpg'].includes(genre) ? genre : 'universal'
    );
    return this.upsertProfile(built);
  }

  private async save(): Promise<void> {
    await fs.mkdir(path.dirname(this.file), { recursive: true });
    const tmp = this.file + '.tmp';
    await fs.writeFile(tmp, JSON.stringify(this.state, null, 2), 'utf8');
    await fs.rename(tmp, this.file);
  }
}
