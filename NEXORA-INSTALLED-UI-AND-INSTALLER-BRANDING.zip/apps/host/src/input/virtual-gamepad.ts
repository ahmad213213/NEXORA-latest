import { createRequire } from 'node:module';
import type { InputEvent } from '@nexora/shared';
import type { InputSink } from './input-manager.js';

/**
 * Virtual Xbox controller sink.
 *
 * Optional native addon `nexora-vigem` (ViGEmBus on Windows) should export:
 *   send(event: InputEvent): Promise<void> | void
 *   releaseAll(): Promise<void> | void
 *
 * Without the driver, games like Cricket 22 will not see a pad — we fail loudly.
 */
type NativeProvider = {
  send(event: InputEvent): Promise<void> | void;
  releaseAll(): Promise<void> | void;
};

let cached: NativeProvider | null | undefined;

function loadProvider(): NativeProvider | null {
  if (cached !== undefined) return cached;
  if (process.platform !== 'win32') {
    cached = null;
    return null;
  }
  try {
    const require = createRequire(import.meta.url);
    const mod = require('nexora-vigem') as { default?: NativeProvider } & NativeProvider;
    const provider = (mod.default ?? mod) as NativeProvider;
    if (typeof provider.send !== 'function' || typeof provider.releaseAll !== 'function') {
      cached = null;
      return null;
    }
    cached = provider;
    return provider;
  } catch {
    cached = null;
    return null;
  }
}

export class VirtualGamepadSink implements InputSink {
  private provider: NativeProvider | null;

  constructor() {
    this.provider = loadProvider();
  }

  get available(): boolean {
    return this.provider !== null;
  }

  async send(event: InputEvent): Promise<void> {
    if (process.platform !== 'win32') {
      throw new Error('Virtual gamepad requires Windows');
    }
    if (!this.provider) {
      throw new Error(
        'Virtual controller is not installed. Install ViGEmBus and the NEXORA gamepad addon so games like Cricket 22 can see a controller.'
      );
    }
    await this.provider.send(event);
  }

  async releaseAll(): Promise<void> {
    if (process.platform !== 'win32' || !this.provider) return;
    await this.provider.releaseAll();
  }
}

/**
 * Routes keyboard/mouse events to SendInput and gamepad events to virtual pad.
 */
export class CompositeInputSink implements InputSink {
  constructor(
    private readonly keyboard: InputSink | null,
    private readonly gamepad: InputSink | null
  ) {}

  async send(event: InputEvent): Promise<void> {
    if (event.kind === 'gamepad-button' || event.kind === 'gamepad-axis') {
      if (!this.gamepad) {
        throw new Error(
          'This game needs a controller. Enable virtual controller (ViGEm) or plug in a real pad.'
        );
      }
      await this.gamepad.send(event);
      return;
    }
    if (!this.keyboard) {
      throw new Error('Keyboard input sink is not available');
    }
    await this.keyboard.send(event);
  }

  async releaseAll(): Promise<void> {
    await this.keyboard?.releaseAll();
    await this.gamepad?.releaseAll();
  }
}
