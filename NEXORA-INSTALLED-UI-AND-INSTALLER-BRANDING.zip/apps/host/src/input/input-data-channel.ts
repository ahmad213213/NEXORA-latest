import { decodeInputFrame, encodeInputFrame, INPUT_CHANNEL } from '@nexora/shared';
import type { InputEvent } from '@nexora/shared';
import type { InputManager } from './input-manager.js';

export interface InputDataChannel {
  label: string;
  send(data: string): void;
  onMessage(handler: (data: string) => void): void;
  close(): void;
}

/** Binds a WebRTC ordered data channel to the existing replay-safe InputManager. */
export class InputDataChannelRouter {
  private channel: InputDataChannel | null = null;
  constructor(private readonly input: InputManager, private readonly log: (event: string, fields?: object) => void = () => {}) {}

  attach(channel: InputDataChannel): void {
    if (channel.label !== INPUT_CHANNEL) throw new Error('Unexpected input data channel');
    this.detach();
    this.channel = channel;
    channel.onMessage(data => { void this.handle(data); });
  }

  async handle(data: string): Promise<boolean> {
    const event = decodeInputFrame(data);
    if (!event) { this.log('input_frame_rejected'); return false; }
    const accepted = await this.input.handle(event);
    this.log(accepted ? 'input_frame_accepted' : 'input_frame_replayed', { sequence: event.sequence });
    return accepted;
  }

  send(event: InputEvent): void {
    if (!this.channel) return;
    this.channel.send(encodeInputFrame(event));
  }

  detach(): void { this.channel?.close(); this.channel = null; }
}
