import os from 'node:os';

export interface SystemStats {
  cpuPercent: number;
  cpuGhz: number;
  ramPercent: number;
  ramUsedGb: number;
  ramTotalGb: number;
}

interface OsLike {
  cpus(): Array<{ speed: number; times: { user: number; nice: number; sys: number; idle: number; irq: number } }>;
  totalmem(): number;
  freemem(): number;
}

/** Real host numbers from the operating system (no GPU figure: the OS does not expose one portably). */
export function createStatsReader(source: OsLike = os) {
  const snapshot = () => {
    let idle = 0; let total = 0;
    for (const cpu of source.cpus()) {
      const t = cpu.times;
      idle += t.idle; total += t.user + t.nice + t.sys + t.idle + t.irq;
    }
    return { idle, total };
  };
  let previous = snapshot();
  let lastPercent = 0;
  return function read(): SystemStats {
    const now = snapshot();
    const totalDelta = now.total - previous.total;
    if (totalDelta > 0) lastPercent = Math.max(0, Math.min(100, Math.round(100 * (1 - (now.idle - previous.idle) / totalDelta))));
    previous = now;
    const cpus = source.cpus();
    const totalMem = source.totalmem();
    const used = Math.max(0, totalMem - source.freemem());
    return {
      cpuPercent: lastPercent,
      cpuGhz: cpus.length ? Math.round(cpus[0].speed / 100) / 10 : 0,
      ramPercent: totalMem ? Math.round(100 * used / totalMem) : 0,
      ramUsedGb: Math.round(used / 1024 ** 3 * 10) / 10,
      ramTotalGb: Math.round(totalMem / 1024 ** 3 * 10) / 10
    };
  };
}
