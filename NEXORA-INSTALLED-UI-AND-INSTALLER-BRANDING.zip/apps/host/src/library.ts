export type GameStatus = 'verified' | 'pending' | 'failed';

export interface GameMetadata {
  title: string;
  description: string;
  genres: string[];
  gameType: string;
  platform: 'windows' | 'unknown';
  provider: string;
  sourceUrl: string;
  cover?: { path: string; mime: string };
  releaseDate?: string;
  /** Extra data loaded by NEXORA ORBIT (optional; older records do not have it). */
  shortDescription?: string;
  developers?: string[];
  publishers?: string[];
  screenshots?: Array<{ file: string; mime: string }>;
  orbit?: { fetchedAt: string; coverWidth?: number; coverHeight?: number; coverSource?: string; coverFullQuality?: boolean; notices: string[] };
}

export interface GameRecord {
  id: string;
  exePath: string;
  name: string;
  status: GameStatus;
  metadata?: GameMetadata;
  playTimeSeconds: number;
  lastPlayedAt?: string;
  pinned: boolean;
  createdAt: string;
  updatedAt: string;
}

const WINDOWS_EXE = /^(?:[A-Za-z]:[\\/]|\\\\)[^\0]+\.exe$/i;
const RESERVED = /[<>"|?*\0]/;

export function normalizeGameName(input: string): string {
  return input.replace(/\.exe$/i, '').replace(/[._-]+/g, ' ').replace(/\s+/g, ' ').trim();
}

export function validateExecutablePath(input: unknown): string {
  if (typeof input !== 'string') throw new Error('Executable path must be a string');
  const value = input.trim();
  if (!WINDOWS_EXE.test(value) || RESERVED.test(value)) throw new Error('Invalid Windows executable path');
  return value;
}

export function createPendingGame(exePath: string, now = new Date()): GameRecord {
  const safePath = validateExecutablePath(exePath);
  const name = normalizeGameName(safePath.split(/[\\/]/).pop() || 'Unknown Game');
  const stamp = now.toISOString();
  return {
    id: `game_${cryptoRandomId()}`,
    exePath: safePath,
    name: name || 'Unknown Game',
    status: 'pending',
    playTimeSeconds: 0,
    pinned: false,
    createdAt: stamp,
    updatedAt: stamp
  };
}

export function commitVerifiedGame(pending: GameRecord, metadata: GameMetadata, now = new Date()): GameRecord {
  if (pending.status !== 'pending') throw new Error('Only pending games can be committed');
  const stamp = now.toISOString();
  return { ...pending, status: 'verified', metadata, updatedAt: stamp };
}

export function markGameFailed(pending: GameRecord, now = new Date()): GameRecord {
  return { ...pending, status: 'failed', updatedAt: now.toISOString() };
}

export function updatePlayState(game: GameRecord, deltaSeconds: number, now = new Date()): GameRecord {
  const delta = Number.isFinite(deltaSeconds) ? Math.max(0, Math.floor(deltaSeconds)) : 0;
  return { ...game, playTimeSeconds: game.playTimeSeconds + delta, lastPlayedAt: now.toISOString(), updatedAt: now.toISOString() };
}

export function togglePinned(game: GameRecord): GameRecord {
  return { ...game, pinned: !game.pinned, updatedAt: new Date().toISOString() };
}

function cryptoRandomId(): string {
  const bytes = new Uint8Array(12);
  if (globalThis.crypto?.getRandomValues) globalThis.crypto.getRandomValues(bytes);
  else for (let i = 0; i < bytes.length; i++) bytes[i] = (i * 73 + 19) & 255;
  return Array.from(bytes, x => x.toString(16).padStart(2, '0')).join('');
}
