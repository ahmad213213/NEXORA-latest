/* Electron frameless window controls for the preview-matched UI.
   Safe in browser preview: no-ops when window.nexora is missing. */
(function () {
  const api = typeof window !== 'undefined' ? window.nexora : null;
  const isElectron = !!(api && (api.windowMinimize || api.windowClose));

  if (!isElectron) {
    // Browser PREVIEW.bat path: hide chrome so layout matches pure prototype
    document.body.classList.remove('electron-shell');
    const chrome = document.getElementById('winChrome');
    if (chrome) chrome.hidden = true;
    return;
  }

  document.body.classList.add('electron-shell');

  const minBtn = document.getElementById('winMin');
  const maxBtn = document.getElementById('winMax');
  const closeBtn = document.getElementById('winClose');

  minBtn?.addEventListener('click', () => {
    try { api.windowMinimize?.(); } catch (_) { /* ignore */ }
  });

  maxBtn?.addEventListener('click', async () => {
    try {
      await api.windowMaximize?.();
      const maximized = await api.windowIsMaximized?.();
      if (maxBtn) maxBtn.textContent = maximized ? '❐' : '□';
    } catch (_) { /* ignore */ }
  });

  closeBtn?.addEventListener('click', () => {
    try { api.windowClose?.(); } catch (_) { /* ignore */ }
  });
})();
