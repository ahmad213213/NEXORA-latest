(() => {
  "use strict";
  const BACKGROUNDS = [
    { id: "space-horizon", name: "Space Horizon", src: "assets/backgrounds/space-horizon.jpg" },
    { id: "nebula", name: "Nebula", src: "assets/backgrounds/nebula.jpg" },
    { id: "forest-vista", name: "Forest Vista", src: "assets/backgrounds/forest-vista.jpg" },
    { id: "earth-orbit", name: "Earth Orbit", src: "assets/backgrounds/earth-orbit.jpg" }
  ];
  const STORAGE_KEY = "nexora.ui-preview.emptyBackgroundIndex.v1";
  let selectedIndex = 0;
  try {
    const storage = window.localStorage;
    const previousRaw = storage.getItem(STORAGE_KEY);
    if (previousRaw !== null) {
      const previous = Number.parseInt(previousRaw, 10);
      if (Number.isInteger(previous) && previous >= 0 && previous < BACKGROUNDS.length) {
        selectedIndex = (previous + 1) % BACKGROUNDS.length;
      }
    }
    storage.setItem(STORAGE_KEY, String(selectedIndex));
  } catch {
    // Local-file browsers may restrict storage. Use a deterministic time-based fallback rather than fail the preview.
    selectedIndex = Math.floor(Date.now() / 1000) % BACKGROUNDS.length;
  }
  const selected = BACKGROUNDS[selectedIndex];
  const root = document.documentElement;
  root.style.setProperty("--nexora-empty-wallpaper", `url("${selected.src}")`);
  root.dataset.nexoraEmptyBackground = selected.id;
  root.dataset.nexoraEmptyBackgroundName = selected.name;
  window.NEXORAEmptyBackground = Object.freeze({ ...selected, index: selectedIndex, total: BACKGROUNDS.length });
})();
