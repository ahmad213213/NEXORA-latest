// Types for the embedded NEXORA ORBIT library (orbit-lib.mjs). Only the surface the host uses.
export interface OrbitProviderStatus {
  provider: string;
  label: string;
  itemCount: number;
  status: string;
  message?: string | null;
  queryUsed?: string;
}
export interface OrbitAlternative {
  id?: string;
  provider: string;
  providerId: string;
  sourceUrl?: string;
  coverImageUrl?: string | null;
}
export interface OrbitGame {
  id: string;
  provider: string;
  providerId: string;
  title: string;
  sourceUrl?: string;
  coverImageUrl?: string | null;
  matchScore: number;
  alsoOn?: string[];
  alternatives?: OrbitAlternative[];
}
export interface OrbitSearchResult {
  query: string;
  expandedQueries: string[];
  fuzzy: boolean;
  hiddenLowMatches: number;
  providers: OrbitProviderStatus[];
  games: OrbitGame[];
}
export interface OrbitRecord {
  title: string;
  steamAppId: string | null;
  storeUrl: string | null;
  coverImageUrl: string | null;
  coverImageCandidates: string[];
  shortDescription: string;
  description: string;
  releaseDate: string;
  developers: string[];
  publishers: string[];
  genres: string[];
  screenshots: Array<{ thumbnailUrl: string; imageUrl: string }>;
  fetchedAt: string;
  [key: string]: unknown;
}
export interface OrbitImage {
  buf: Uint8Array;
  ext: string;
  url: string;
  width: number;
  height: number;
}
export interface OrbitBestCover extends OrbitImage {
  orientation: string;
  source: string;
  fullQuality: boolean;
  tried: number;
  downloaded: number;
}
export function searchGames(query: string, options?: { limit?: number; fuzzy?: boolean }): Promise<OrbitSearchResult>;
export function getGameDetails(
  title: string,
  options?: { steamAppId?: string; extraCoverUrls?: string[] }
): Promise<{ record: OrbitRecord | null; notices: string[] }>;
export function downloadBestCover(urls: string[]): Promise<OrbitBestCover>;
export function downloadImage(url: string): Promise<OrbitImage>;
export function setAliases(extra: Record<string, string>): void;
export function describeError(err: unknown): { status: string; message: string };
