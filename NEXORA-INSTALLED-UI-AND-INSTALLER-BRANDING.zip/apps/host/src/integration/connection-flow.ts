import type { SessionState } from '@nexora/shared';
import { SessionOrchestrator } from './session-orchestrator.js';
import { WebRtcPeerSession, type IceCandidateInit, type SessionDescription } from '../webrtc/peer-session.js';
import type { SignalingClient } from '../networking/signaling-client.js';

export interface ConnectionFlowTransport {
  createOffer(): Promise<SessionDescription>;
  createAnswer(): Promise<SessionDescription>;
  setLocalDescription(d: SessionDescription): Promise<void>;
  setRemoteDescription(d: SessionDescription): Promise<void>;
  addIceCandidate(c: IceCandidateInit): Promise<void>;
  close(): Promise<void>;
}

export type ConnectionFlowState = 'idle' | 'pairing' | 'negotiating' | 'connected' | 'disconnected' | 'closed';

/** Coordinates pairing/signaling/WebRTC/media without making the signaling server a media endpoint. */
export class ConnectionFlow {
  private state: ConnectionFlowState = 'idle';
  private sessionId: string | null = null;
  private peer: WebRtcPeerSession | null = null;
  private generation = 0;

  constructor(
    private readonly signaling: SignalingClient,
    private readonly media: SessionOrchestrator,
    private readonly transportFactory: (onIce: (c: IceCandidateInit) => void, onState: (s: ConnectionFlowState) => void) => ConnectionFlowTransport,
    private readonly log: (event: string, fields?: object) => void = () => {}
  ) {}

  getState(): ConnectionFlowState { return this.state; }

  async connect(peerId: string): Promise<string> {
    if (!/^[a-f0-9]{32}$/.test(peerId)) throw new Error('Invalid peer ID');
    await this.close();
    const g = ++this.generation;
    this.state = 'negotiating';
    const id = this.signaling.createSession(peerId);
    this.sessionId = id;
    const transport = this.transportFactory(
      candidate => { if (g === this.generation && this.sessionId === id) this.signaling.sendSession('ice.candidate', id, peerId, { candidate }); },
      state => { if (g !== this.generation || this.sessionId !== id) return; this.state = state; }
    );
    const peer = new WebRtcPeerSession(transport, { onState: s => { if (g === this.generation && this.sessionId === id) this.log('webrtc_state', { sessionId: id, state: s }); } });
    this.peer = peer;
    const offer = await peer.createOffer();
    if (g !== this.generation || this.sessionId !== id) throw new Error('Stale connection');
    this.signaling.sendSession('sdp.offer', id, peerId, { type: offer.type, sdp: offer.sdp });
    await this.media.start(id);
    this.signaling.markSession(id, 'negotiating');
    return id;
  }

  async acceptSignal(type: 'sdp.answer' | 'ice.candidate', payload: Record<string, unknown>): Promise<void> {
    const peer = this.peer;
    if (!peer || !this.sessionId) throw new Error('No active connection');
    if (type === 'sdp.answer') {
      if (typeof payload.sdp !== 'string') throw new Error('Invalid SDP answer');
      await peer.acceptAnswer({ type: 'answer', sdp: payload.sdp });
      this.state = 'connected';
      this.signaling.markSession(this.sessionId, 'connected');
      return;
    }
    if (!payload.candidate || typeof payload.candidate !== 'object') throw new Error('Invalid ICE candidate');
    await peer.addIceCandidate(payload.candidate as IceCandidateInit);
  }

  async handleRemoteOffer(peerId: string, offer: SessionDescription): Promise<void> {
    if (!/^[a-f0-9]{32}$/.test(peerId)) throw new Error('Invalid peer ID');
    await this.close();
    const g = ++this.generation;
    const id = this.signaling.createSession(peerId);
    this.sessionId = id;
    this.state = 'negotiating';
    const transport = this.transportFactory(
      candidate => { if (g === this.generation && this.sessionId === id) this.signaling.sendSession('ice.candidate', id, peerId, { candidate }); },
      state => { if (g === this.generation && this.sessionId === id) this.state = state; }
    );
    const peer = new WebRtcPeerSession(transport);
    this.peer = peer;
    const answer = await peer.acceptOffer(offer);
    if (g !== this.generation || this.sessionId !== id) throw new Error('Stale connection');
    this.signaling.sendSession('sdp.answer', id, peerId, { type: answer.type, sdp: answer.sdp });
    await this.media.start(id);
    this.signaling.markSession(id, 'negotiating');
  }

  async disconnect(): Promise<void> { await this.close(); }

  async close(): Promise<void> {
    ++this.generation;
    const id = this.sessionId;
    this.sessionId = null;
    this.state = id ? 'closed' : 'idle';
    if (id) { try { this.signaling.closeSession(id); } catch {} }
    const peer = this.peer; this.peer = null;
    if (peer) await peer.close();
    await this.media.stop();
  }
}
