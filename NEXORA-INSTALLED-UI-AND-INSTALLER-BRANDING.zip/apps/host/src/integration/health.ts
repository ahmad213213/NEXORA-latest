export type ConnectionHealth = 'excellent' | 'good' | 'degraded' | 'poor';

export interface HealthSample {
  rttMs: number;
  packetLossPct: number;
  jitterMs: number;
  decodeFps?: number;
  encodeFps?: number;
}

export interface HealthSnapshot {
  health: ConnectionHealth;
  rttMs: number;
  packetLossPct: number;
  jitterMs: number;
  fpsDropPct: number;
}

function finiteNonNegative(value: number, fallback = 0): number {
  return Number.isFinite(value) && value >= 0 ? value : fallback;
}

export function classifyConnectionHealth(sample: HealthSample): HealthSnapshot {
  const rttMs = finiteNonNegative(sample.rttMs);
  const packetLossPct = Math.min(100, finiteNonNegative(sample.packetLossPct));
  const jitterMs = finiteNonNegative(sample.jitterMs);
  const encodeFps = sample.encodeFps === undefined ? undefined : finiteNonNegative(sample.encodeFps);
  const decodeFps = sample.decodeFps === undefined ? undefined : finiteNonNegative(sample.decodeFps);
  const fpsDropPct = encodeFps && encodeFps > 0 && decodeFps !== undefined
    ? Math.min(100, Math.max(0, ((encodeFps - decodeFps) / encodeFps) * 100))
    : 0;

  let health: ConnectionHealth = 'excellent';
  if (rttMs > 150 || packetLossPct > 3 || jitterMs > 40 || fpsDropPct > 15) health = 'poor';
  else if (rttMs > 90 || packetLossPct > 1.5 || jitterMs > 25 || fpsDropPct > 8) health = 'degraded';
  else if (rttMs > 50 || packetLossPct > 0.5 || jitterMs > 12 || fpsDropPct > 4) health = 'good';

  return { health, rttMs, packetLossPct, jitterMs, fpsDropPct };
}
