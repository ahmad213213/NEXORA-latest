export interface IceServer { urls: string | string[]; username?: string; credential?: string }
export interface IceConfig { iceServers: IceServer[]; iceTransportPolicy: 'all' | 'relay' }
const STUN_RE = /^stun[s]?:[^\s]{1,255}$/i;
const TURN_RE = /^turns?:[^\s]{1,255}$/i;
export function normalizeIceConfig(input: unknown): IceConfig {
  const x = input && typeof input === 'object' && !Array.isArray(input) ? input as Record<string, unknown> : {};
  const raw = Array.isArray(x.iceServers) ? x.iceServers : [];
  const iceServers: IceServer[] = [];
  for (const item of raw.slice(0, 8)) {
    if (!item || typeof item !== 'object' || Array.isArray(item)) continue;
    const o = item as Record<string, unknown>; const urls = Array.isArray(o.urls) ? o.urls.filter(v => typeof v === 'string').slice(0, 8) as string[] : typeof o.urls === 'string' ? [o.urls] : [];
    const valid = urls.filter(u => STUN_RE.test(u) || TURN_RE.test(u)); if (!valid.length) continue;
    const out: IceServer = { urls: valid.length === 1 ? valid[0]! : valid };
    if (typeof o.username === 'string' && o.username.length <= 256) out.username = o.username;
    if (typeof o.credential === 'string' && o.credential.length <= 1024) out.credential = o.credential;
    iceServers.push(out);
  }
  return { iceServers, iceTransportPolicy: x.iceTransportPolicy === 'relay' ? 'relay' : 'all' };
}
