import { promises as fs } from 'node:fs';
import path from 'node:path';
import { createDefaultLayout, normalizeControlLayout, validateControlLayout, type ControlLayout } from '@nexora/shared';
export class LayoutStore {
  private layouts = new Map<string, ControlLayout>();
  constructor(private readonly file: string) {}
  async load(): Promise<ControlLayout[]> {
    this.layouts.clear();
    try { const raw=JSON.parse(await fs.readFile(this.file,'utf8')); if(Array.isArray(raw)) for(const l of raw) if(validateControlLayout(l)) this.layouts.set(l.id,normalizeControlLayout(l)); }
    catch { /* first run */ }
    if(!this.layouts.size){
      for (const genre of ['custom','action','racing','shooter','sports','rpg'] as const) { const d=createDefaultLayout(genre); this.layouts.set(d.id,d); }
      await this.save();
    }
    return this.list();
  }
  list(){ return [...this.layouts.values()].map(l=>structuredClone(l)); }
  get(id:string){ const l=this.layouts.get(id); return l?structuredClone(l):undefined; }
  async upsert(layout:ControlLayout){ const n=normalizeControlLayout(layout); this.layouts.set(n.id,n); await this.save(); return structuredClone(n); }
  async remove(id:string){ if(id.startsWith('layout_') && ['layout_custom','layout_action','layout_racing','layout_shooter','layout_sports','layout_rpg'].includes(id)) return false; const ok=this.layouts.delete(id); if(ok) await this.save(); return ok; }
  private async save(){ await fs.mkdir(path.dirname(this.file),{recursive:true}); const tmp=this.file+'.tmp'; await fs.writeFile(tmp,JSON.stringify(this.list(),null,2),'utf8'); await fs.rename(tmp,this.file); }
}
