import { createDefaultLayout, validateControlLayout, type ControlLayout } from '@nexora/shared';
import { LayoutStore } from './layout-store.js';
export class LayoutController {
  constructor(private readonly store: LayoutStore) {}
  async list(){ return this.store.list(); }
  async ensureDefaults(){ for(const g of ['custom','action','racing','shooter','sports','rpg'] as const){ const id=`layout_${g}`; if(!this.store.get(id)) await this.store.upsert(createDefaultLayout(g)); } return this.list(); }
  async save(layout: unknown){ if(!validateControlLayout(layout)) throw new Error('Invalid control layout'); return this.store.upsert(layout as ControlLayout); }
  async remove(id:string){ return this.store.remove(id); }
}
