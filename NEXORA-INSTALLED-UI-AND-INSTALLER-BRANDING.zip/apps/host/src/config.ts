import { app } from 'electron';
import { mkdir, readFile, rename, rm, writeFile } from 'node:fs/promises';
import path from 'node:path';

/** Stream output tiers only (Host UI follows the display, not these). */
export type QualityPreset = '480p' | '720p' | '1080p' | '1440p';

/** Host operating modes. */
export type HostMode = 'balanced' | 'power_saving' | 'data_saver' | 'performance';
export type AppearanceTheme = 'midnight' | 'obsidian' | 'earth';
export type AccentColor = 'cyan' | 'blue' | 'violet' | 'amber' | 'emerald' | 'rose';
export type LaunchMode = 'desktop' | 'console';

export interface AppearanceSettings {
  theme: AppearanceTheme;
  accent: AccentColor;
  reducedMotion: boolean;
}

export interface VideoSettings {
  width: number;
  height: number;
  fps: number;
  bitrateKbps: number;
}

export interface HostConfig {
  /** Bumped when the stored config shape changes; old config files are normalized on read. */
  version: 3;
  /** Name shown in the desktop and console UI. */
  profileName: string;
  /** UI surface to open on the next launch. */
  launchMode: LaunchMode;
  appearance: AppearanceSettings;
  startWithWindows: boolean;
  keepInTray: boolean;
  remoteAccess: boolean;
  /** Active operating mode. */
  mode: HostMode;
  /** User-selected quality when mode does not force a preset. */
  qualityPreset: QualityPreset;
  video: VideoSettings;
  streaming: {
    capture: 'ddagrab' | 'gdigrab';
    encoder: 'auto' | 'nvenc' | 'qsv' | 'amf' | 'x264';
    ffmpegPath: string;
    audioDevice: string | null;
  };
}

/** Fixed quality tables. Bitrate targets tuned for low-Mbps playability. */
export const QUALITY_PRESETS: Record<QualityPreset, VideoSettings> = {
  '480p': { width: 854, height: 480, fps: 30, bitrateKbps: 1500 },
  '720p': { width: 1280, height: 720, fps: 30, bitrateKbps: 3500 },
  '1080p': { width: 1920, height: 1080, fps: 60, bitrateKbps: 8000 },
  '1440p': { width: 2560, height: 1440, fps: 60, bitrateKbps: 14000 }
};

/** What each mode forces (or allows). */
export const MODE_POLICY: Record<HostMode, {
  label: string;
  description: string;
  /** Forced quality, or null = use qualityPreset */
  forceQuality: QualityPreset | null;
  minimalUi: boolean;
  maxFps: number;
}> = {
  balanced: {
    label: 'Balanced',
    description: 'Default quality and full UI.',
    forceQuality: null,
    minimalUi: false,
    maxFps: 60
  },
  power_saving: {
    label: 'Power Saving',
    description: 'Minimal UI + lowest allowed stream (480p30) to cut host + receiver power use.',
    forceQuality: '480p',
    minimalUi: true,
    maxFps: 30
  },
  data_saver: {
    label: 'Data Saver',
    description: 'Caps stream at 480p max (never raises quality) so mobile data stays low.',
    forceQuality: null, // ceiling applied in resolveVideoForConfig
    minimalUi: false,
    maxFps: 30
  },
  performance: {
    label: 'Performance',
    description: 'Higher quality when the link can handle it (ABR still protects weak links).',
    forceQuality: null,
    minimalUi: false,
    maxFps: 60
  }
};

export function resolveVideoForConfig(mode: HostMode, qualityPreset: QualityPreset): VideoSettings {
  const policy = MODE_POLICY[mode];
  // Only 480p / 720p / 1080p / 1440p are legal stream outputs.
  // Power saving forces 480p. Data saver is a CEILING at 480p (never raises quality).
  let preset: QualityPreset = qualityPreset;
  if (mode === 'power_saving') {
    preset = '480p';
  } else if (mode === 'data_saver') {
    const order: QualityPreset[] = ['480p', '720p', '1080p', '1440p'];
    const idx = order.indexOf(qualityPreset);
    const cap = order.indexOf('480p');
    preset = order[Math.min(idx < 0 ? cap : idx, cap)]!;
  } else if (policy.forceQuality) {
    preset = policy.forceQuality;
  }
  if (!(preset in QUALITY_PRESETS)) preset = '720p';
  const base = { ...QUALITY_PRESETS[preset] };
  if (base.fps > policy.maxFps) base.fps = policy.maxFps;
  return base;
}

export const DEFAULT_CONFIG: HostConfig = {
  version: 3,
  profileName: 'My PC',
  launchMode: 'desktop',
  appearance: { theme: 'midnight', accent: 'cyan', reducedMotion: false },
  startWithWindows: false,
  keepInTray: false,
  remoteAccess: true,
  mode: 'balanced',
  qualityPreset: '720p',
  video: { ...QUALITY_PRESETS['720p'] },
  streaming: { capture: 'ddagrab', encoder: 'auto', ffmpegPath: 'ffmpeg.exe', audioDevice: null }
};

function configPath(): string {
  return path.join(app.getPath('userData'), 'config.json');
}

function quarantinePath(): string {
  return path.join(app.getPath('userData'), `config.invalid.${Date.now()}.json`);
}

function asMode(value: unknown): HostMode {
  return value === 'power_saving' || value === 'data_saver' || value === 'performance' || value === 'balanced'
    ? value
    : DEFAULT_CONFIG.mode;
}

function asPreset(value: unknown): QualityPreset {
  return value === '480p' || value === '720p' || value === '1080p' || value === '1440p'
    ? value
    : DEFAULT_CONFIG.qualityPreset;
}

function asTheme(value: unknown): AppearanceTheme {
  return value === 'obsidian' || value === 'earth' || value === 'midnight' ? value : DEFAULT_CONFIG.appearance.theme;
}

function asAccent(value: unknown): AccentColor {
  return value === 'blue' || value === 'violet' || value === 'amber' || value === 'emerald' || value === 'rose' || value === 'cyan'
    ? value
    : DEFAULT_CONFIG.appearance.accent;
}

function asProfileName(value: unknown): string {
  if (typeof value !== 'string') return DEFAULT_CONFIG.profileName;
  const cleaned = value.replace(/[\u0000-\u001f\u007f]/g, '').trim().slice(0, 32);
  return cleaned || DEFAULT_CONFIG.profileName;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value && typeof value === 'object' && !Array.isArray(value));
}

/** Normalize current settings and safely migrate older saved config shapes. */
export function normalize(input: unknown): HostConfig {
  const x = isRecord(input) ? input : {};
  const mode = asMode(x.mode);
  const qualityPreset = asPreset(x.qualityPreset);
  const video = resolveVideoForConfig(mode, qualityPreset);

  const appearanceInput = isRecord(x.appearance) ? x.appearance : {};
  const streaming = isRecord(x.streaming) ? x.streaming : {};
  const encoder = ['auto', 'nvenc', 'qsv', 'amf', 'x264'].includes(String(streaming.encoder))
    ? String(streaming.encoder) as HostConfig['streaming']['encoder']
    : DEFAULT_CONFIG.streaming.encoder;
  const capture = streaming.capture === 'gdigrab' ? 'gdigrab' : 'ddagrab';
  const ffmpegPath = typeof streaming.ffmpegPath === 'string' && streaming.ffmpegPath.trim() && streaming.ffmpegPath.length <= 512
    ? streaming.ffmpegPath.trim()
    : DEFAULT_CONFIG.streaming.ffmpegPath;
  const audioDevice = typeof streaming.audioDevice === 'string' && streaming.audioDevice.trim() && streaming.audioDevice.length <= 512
    ? streaming.audioDevice.trim()
    : null;

  return {
    version: 3,
    profileName: asProfileName(x.profileName),
    launchMode: x.launchMode === 'console' ? 'console' : 'desktop',
    appearance: {
      theme: asTheme(appearanceInput.theme),
      accent: asAccent(appearanceInput.accent),
      reducedMotion: appearanceInput.reducedMotion === true
    },
    startWithWindows: x.startWithWindows === true,
    keepInTray: x.keepInTray === true,
    remoteAccess: x.remoteAccess !== false,
    mode,
    qualityPreset,
    video,
    streaming: { capture, encoder, ffmpegPath, audioDevice }
  };
}

/**
 * Merge an untrusted partial IPC patch onto the current settings. Nested appearance
 * and streaming preferences are merged independently so editing one field never
 * resets sibling values. normalize() is the final validation boundary.
 */
export function mergeConfigPatch(current: HostConfig, patch: unknown): HostConfig {
  if (!isRecord(patch)) throw new Error('Settings must be an object.');

  const requireBoolean = (key: string): void => {
    if (key in patch && typeof patch[key] !== 'boolean') throw new Error(`${key} must be true or false.`);
  };
  const requireChoice = (key: string, values: readonly string[]): void => {
    if (key in patch && (typeof patch[key] !== 'string' || !values.includes(patch[key] as string))) {
      throw new Error(`${key} contains an unsupported value.`);
    }
  };

  requireBoolean('startWithWindows');
  requireBoolean('keepInTray');
  requireBoolean('remoteAccess');
  requireChoice('mode', ['balanced', 'power_saving', 'data_saver', 'performance']);
  requireChoice('qualityPreset', ['480p', '720p', '1080p', '1440p']);
  requireChoice('launchMode', ['desktop', 'console']);
  if ('profileName' in patch && typeof patch.profileName !== 'string') throw new Error('PC display name must be text.');

  let patchAppearance: Record<string, unknown> = {};
  if ('appearance' in patch) {
    if (!isRecord(patch.appearance)) throw new Error('Appearance settings must be an object.');
    patchAppearance = patch.appearance;
    const appearanceFields: Record<string, readonly string[]> = {
      theme: ['midnight', 'obsidian', 'earth'],
      accent: ['cyan', 'blue', 'violet', 'amber', 'emerald', 'rose']
    };
    for (const [key, values] of Object.entries(appearanceFields)) {
      if (key in patchAppearance && (typeof patchAppearance[key] !== 'string' || !values.includes(patchAppearance[key] as string))) {
        throw new Error(`appearance.${key} contains an unsupported value.`);
      }
    }
    if ('reducedMotion' in patchAppearance && typeof patchAppearance.reducedMotion !== 'boolean') {
      throw new Error('appearance.reducedMotion must be true or false.');
    }
  }

  let patchStreaming: Record<string, unknown> = {};
  if ('streaming' in patch) {
    if (!isRecord(patch.streaming)) throw new Error('Streaming settings must be an object.');
    patchStreaming = patch.streaming;
    if ('capture' in patchStreaming && !['ddagrab', 'gdigrab'].includes(String(patchStreaming.capture))) {
      throw new Error('streaming.capture contains an unsupported value.');
    }
    if ('encoder' in patchStreaming && !['auto', 'nvenc', 'qsv', 'amf', 'x264'].includes(String(patchStreaming.encoder))) {
      throw new Error('streaming.encoder contains an unsupported value.');
    }
    if ('ffmpegPath' in patchStreaming && typeof patchStreaming.ffmpegPath !== 'string') {
      throw new Error('streaming.ffmpegPath must be text.');
    }
    if ('audioDevice' in patchStreaming && patchStreaming.audioDevice !== null && typeof patchStreaming.audioDevice !== 'string') {
      throw new Error('streaming.audioDevice must be text or null.');
    }
  }

  return normalize({
    ...current,
    ...patch,
    appearance: { ...current.appearance, ...patchAppearance },
    streaming: { ...current.streaming, ...patchStreaming }
  });
}

export async function loadConfig(): Promise<HostConfig> {
  try {
    return normalize(JSON.parse(await readFile(configPath(), 'utf8')));
  } catch {
    try {
      await rename(configPath(), quarantinePath());
    } catch {
      // Missing file or an already-moved file is fine.
    }
    return normalize(DEFAULT_CONFIG);
  }
}

// Serialize disk writes so fast successive UI changes cannot collide on a shared .tmp file.
let saveChain: Promise<unknown> = Promise.resolve();
let saveSequence = 0;

export function saveConfig(input: unknown): Promise<HostConfig> {
  const operation = saveChain.then(async () => {
    const value = normalize(input);
    const dir = app.getPath('userData');
    await mkdir(dir, { recursive: true });
    const tmp = `${configPath()}.${process.pid}.${++saveSequence}.tmp`;
    try {
      await writeFile(tmp, JSON.stringify(value, null, 2), { encoding: 'utf8', mode: 0o600 });
      await rename(tmp, configPath());
      return value;
    } catch (error) {
      // Do not leave incomplete temp files after an interrupted write.
      try { await rm(tmp, { force: true }); } catch { /* best effort */ }
      throw error;
    }
  });
  saveChain = operation.then(() => undefined, () => undefined);
  return operation;
}
