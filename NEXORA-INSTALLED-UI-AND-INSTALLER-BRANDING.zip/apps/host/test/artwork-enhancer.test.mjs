import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const root = new URL('../src/', import.meta.url);

test('artwork enhancement is applied to newly fetched covers and screenshots', async () => {
  const controller = await readFile(new URL('library-controller.ts', root), 'utf8');
  assert.match(controller, /enhanceArtwork\(loaded\.cover\.bytes/);
  assert.match(controller, /enhanceArtwork\(shot\.bytes/);
  assert.match(controller, /enhanceArtwork\(selected\.cover\.bytes/);
});

test('enhancement failures preserve the original artwork and do not block adding games', async () => {
  const enhancer = await readFile(new URL('orbit/artwork-enhancer.ts', root), 'utf8');
  assert.match(enhancer, /if \(!exe\) return original/);
  assert.match(enhancer, /catch \{\s*return original;\s*\}/);
  assert.match(enhancer, /MAX_OUTPUT_BYTES/);
});

test('artwork presentation crops to its container without stretching', async () => {
  const css = await readFile(new URL('ui/styles.css', root), 'utf8');
  assert.match(css, /background-size:cover/);
  assert.match(css, /object-fit:cover/);
});
