import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { mkdirSync } from 'node:fs';

execFileSync(process.execPath, ['-e', `import('./packages/shared/dist/input-frame.js').then(async m => {
 const e={kind:'key',action:'down',code:'KeyW',sequence:1,timestamp:123};
 const s=m.encodeInputFrame(e); if(m.decodeInputFrame(s)?.sequence!==1) process.exit(2);
 if(m.decodeInputFrame('{"v":1,"type":"input","event":{"kind":"key","action":"down","code":"KeyW","sequence":1,"timestamp":123}}')?.code!=='KeyW') process.exit(3);
 if(m.decodeInputFrame('x'.repeat(9000))!==null) process.exit(4);
 console.log('input frame runtime: 3/3 PASS');
})`], {stdio:'inherit'});
