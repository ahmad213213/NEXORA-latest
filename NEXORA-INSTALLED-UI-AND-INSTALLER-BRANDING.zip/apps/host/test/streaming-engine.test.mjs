import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(new URL('../', import.meta.url).pathname);
const src = name => fs.readFileSync(path.join(root, 'src/streaming', name), 'utf8');

const ffmpeg = src('ffmpeg.ts');
const capture = src('capture-engine.ts');
const adaptive = src('adaptive-bitrate.ts');

for (const [name, pattern] of [
  ['ddagrab capture', /ddagrab=output_idx=0/],
  ['gdigrab fallback', /-f', 'gdigrab/],
  ['NVENC', /h264_nvenc/],
  ['QSV', /h264_qsv/],
  ['AMF', /h264_amf/],
  ['x264', /libx264/],
  ['one second GOP', /GOP_SECONDS = 1/],
  ['Opus 48 kHz', /libopus[\s\S]*48000/],
  ['bounded audio restart', /audioRestarts < 2/],
  ['hardware fallback', /this\.encoder = 'x264'/],
  ['generation ownership', /generation !== this\.generation/],
  ['ABR cooldown', /upCooldown/]
]) {
  test(name, () => assert.match(`${ffmpeg}\n${capture}\n${adaptive}`, pattern));
}
