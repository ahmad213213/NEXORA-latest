import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile, access } from 'node:fs/promises';

// The window uses sandbox:true. A sandboxed preload cannot be an ES module, so
// the preload must be CommonJS (.cts -> preload.cjs) even though the package is "type": "module".
test('sandboxed preload is CommonJS and main loads preload.cjs', async () => {
  const main = await readFile(new URL('../src/main.ts', import.meta.url), 'utf8');
  assert.match(main, /sandbox:\s*true/);
  assert.match(main, /preload:\s*path\.join\(__dirname,\s*'preload\.cjs'\)/);
  await access(new URL('../src/preload.cts', import.meta.url));
  const tsconfig = await readFile(new URL('../tsconfig.json', import.meta.url), 'utf8');
  assert.match(tsconfig, /\*\.cts/);
});
