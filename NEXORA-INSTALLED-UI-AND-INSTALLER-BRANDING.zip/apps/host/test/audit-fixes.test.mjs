import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, writeFile, readFile } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '..', '..', '..');
const ui = path.resolve(here, '..', 'src', 'ui');
const read = (...p) => readFile(path.join(...p), 'utf8');

test('library order parses ISO dates (Number(ISO) is NaN)', async () => {
  const js = await read(ui, 'app.js');
  assert.doesNotMatch(js, /Number\([a-z]\.lastPlayedAt/);
  assert.match(js, /Date\.parse\(game\?\.lastPlayedAt/);
});

test('UI loads nothing from the internet and uses no plain confirm()', async () => {
  const [html, css, js] = await Promise.all([read(ui, 'index.html'), read(ui, 'styles.css'), read(ui, 'app.js')]);
  for (const text of [html, css, js]) assert.doesNotMatch(text, /unsplash/i);
  assert.doesNotMatch(html, /img-src[^;]*https:/);
  assert.doesNotMatch(html, /frame-ancestors/);
  assert.doesNotMatch(js, /\bconfirm\(/);
});

test('PC status shows live values, not typed-in numbers', async () => {
  const html = await read(ui, 'index.html');
  assert.doesNotMatch(html, /41%|68%|54%|12\.4 Mbps|8\.6 \/ 16 GB/);
  assert.match(html, /PC status|usageCpu|ringCpu/);
  assert.match(html, /id="usageCpu"/);
});

test('no text in the UI is smaller than 11px', async () => {
  const css = await read(ui, 'styles.css');
  for (const m of css.matchAll(/font-size:([0-9.]+)px/g)) assert.ok(Number(m[1]) >= 10, `font-size ${m[1]}px`);
});

test('a close button never hides a whole dialog for good', async () => {
  const js = await read(ui, 'app.js');
  assert.doesNotMatch(js, /querySelectorAll\('\.close-card'\)/);
});

test('system stats reader returns real, bounded numbers', async () => {
  const { createStatsReader } = await import('../dist/system-stats.js');
  let idle = 0; let busy = 0;
  const fake = {
    cpus: () => [{ speed: 3600, times: { user: busy, nice: 0, sys: 0, idle, irq: 0 } }],
    totalmem: () => 16 * 1024 ** 3,
    freemem: () => 4 * 1024 ** 3
  };
  const read = createStatsReader(fake);
  idle += 50; busy += 50;
  const stats = read();
  assert.equal(stats.cpuPercent, 50);
  assert.equal(stats.cpuGhz, 3.6);
  assert.equal(stats.ramPercent, 75);
  assert.equal(stats.ramUsedGb, 12);
  assert.equal(stats.ramTotalGb, 16);
});

test('update settings come from env first, then from small files', async () => {
  const { loadUpdateSettings } = await import('../dist/update/settings.js');
  const dir = await mkdtemp(path.join(os.tmpdir(), 'nx-upd-'));
  assert.deepEqual(await loadUpdateSettings(dir, {}), { manifestUrl: '', publicKeyB64: '' });
  await writeFile(path.join(dir, 'update-url.txt'), '\uFEFFhttps://example.test/m.json\r\n');
  await writeFile(path.join(dir, 'update-public-key.txt'), 'KEY123\n');
  assert.deepEqual(await loadUpdateSettings(dir, {}), { manifestUrl: 'https://example.test/m.json', publicKeyB64: 'KEY123' });
  assert.equal((await loadUpdateSettings(dir, { NEXORA_UPDATE_MANIFEST_URL: 'https://env.test/m.json' })).manifestUrl, 'https://env.test/m.json');
});

test('an unset update key means "not configured", not "up to date"', async () => {
  const { checkUpdate } = await import('../dist/update/updater.js');
  const result = await checkUpdate('1.0.0', 'https://example.test/m.json', 'REPLACE_WITH_RELEASE_PUBLIC_KEY_BASE64');
  assert.equal(result.available, false);
  assert.equal(result.reason, 'Update service not configured');
});

test('updater helpers: backup must be outside the install folder; zip must be a real zip', async () => {
  const { isInsideFolder, assertZipFile } = await import('../dist/update/updater.js');
  assert.equal(isInsideFolder('C:\\Apps\\NEXORA', 'C:\\Apps\\NEXORA\\backup.zip'), process.platform === 'win32');
  assert.equal(isInsideFolder('/opt/nexora', '/opt/nexora/backup.zip'), true);
  assert.equal(isInsideFolder('/opt/nexora', '/opt/nexora-backups/b.zip'), false);
  const dir = await mkdtemp(path.join(os.tmpdir(), 'nx-zip-'));
  const fake = path.join(dir, 'x.zip'); await writeFile(fake, 'not a zip at all, just text here.');
  await assert.rejects(() => assertZipFile(fake), /valid zip/);
  const good = path.join(dir, 'ok.zip'); await writeFile(good, Buffer.concat([Buffer.from([0x50, 0x4b, 3, 4]), Buffer.alloc(40)]));
  await assertZipFile(good);
  await assert.rejects(() => assertZipFile(path.join(dir, 'x.txt')), /\.zip/);
});

test('local update script: backup first, safe zip, progress, rollback, no read-only $Pid parameter', async () => {
  const script = await read(root, 'scripts/release/apply-local-update.ps1');
  for (const pattern of [/CreateFromDirectory/, /Assert-SafeZip/, /ProgressBar/, /Move-Item -LiteralPath \$old/, /ValidateSet\('patch','restore'\)/, /RunAs/]) assert.match(script, pattern);
  assert.ok(script.indexOf('CreateFromDirectory') < script.indexOf('ExtractToDirectory'), 'backup is made before anything is replaced');
  assert.doesNotMatch(script, /\$Pid\b/);
  assert.doesNotMatch(await read(root, 'scripts/release/apply-update.ps1'), /\$Pid\b/);
});

test('new IPC handlers check the sender and the bridge exposes them', async () => {
  const main = await read(here, '..', 'src', 'main.ts');
  const preload = await read(here, '..', 'src', 'preload.cts');
  for (const channel of ['update:from-file', 'system:stats']) {
    const start = main.indexOf(`ipcMain.handle('${channel}'`);
    assert.ok(start > 0, channel);
    assert.match(main.slice(start, start + 220), /isTrustedSender/);
    assert.match(preload, new RegExp(channel));
  }
  assert.match(main, /if \(!app\.isPackaged\) return \{ status: 'unavailable'/);
});
