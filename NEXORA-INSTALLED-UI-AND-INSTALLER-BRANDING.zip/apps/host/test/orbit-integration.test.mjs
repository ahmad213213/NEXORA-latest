import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = file => readFile(path.join(root, file), 'utf8');

test('every ORBIT IPC handler rejects untrusted senders and validates its input', async () => {
  const main = await read('src/main.ts');
  for (const channel of ['library:begin-add', 'orbit:search', 'orbit:choose', 'orbit:cancel']) {
    const start = main.indexOf(`ipcMain.handle('${channel}'`);
    assert.ok(start > 0, `${channel} handler exists`);
    const body = main.slice(start, start + 700);
    assert.match(body, /isTrustedSender\(event\)/, `${channel} checks the sender`);
  }
  assert.match(main, /PENDING_ID\s*=\s*\/\^game_\[a-f0-9\]\{24\}\$\//);
});

test('the renderer can never hand a URL or path to the ORBIT downloader', async () => {
  const preload = await read('src/preload.cts');
  for (const line of preload.split('\n').filter(l => /orbit/i.test(l) && /invoke/.test(l))) {
    assert.doesNotMatch(line, /url|path|href/i, line.trim());
  }
  const search = await read('src/orbit/orbit-search.ts');
  assert.match(search, /httpsOnly/);
  assert.match(search, /requestId/);
});

test('ORBIT UI renders provider data with textContent only', async () => {
  const ui = await read('src/ui/app.js');
  const start = ui.indexOf('NEXORA ORBIT add-game flow');
  const end = ui.indexOf("closeMetadata?.addEventListener('click'");
  const orbitUi = ui.slice(start, end);
  assert.ok(orbitUi.length > 1000);
  assert.doesNotMatch(orbitUi, /innerHTML|outerHTML|insertAdjacentHTML/);
  assert.match(orbitUi, /beginAddGame/);
  assert.match(orbitUi, /window\.nexora\.addGame\(\)/, 'old flow stays as fallback');
});

test('ORBIT files are shipped and typed', async () => {
  const copy = await read('scripts/copy-static.mjs');
  assert.match(copy, /src', 'orbit'/);
  const tsconfig = await read('tsconfig.json');
  assert.match(tsconfig, /\*\.d\.mts/);
  const lib = await read('src/orbit/orbit-lib.mjs');
  assert.match(lib, /export async function downloadImage/);
});

test('window CSP lets the modal show data: thumbnails and nexora-cover screenshots only', async () => {
  const html = await read('src/ui/index.html');
  assert.match(html, /img-src 'self' data: nexora-cover:/);
  assert.doesNotMatch(html, /img-src[^;]*https:\/\/(?!images\.unsplash\.com)/);
});
