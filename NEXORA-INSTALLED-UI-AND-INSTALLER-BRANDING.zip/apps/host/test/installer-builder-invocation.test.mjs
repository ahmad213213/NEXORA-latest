import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile, access } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '../../..');

const packageText = await readFile(path.join(root, 'package.json'), 'utf8');
const installerPath = path.join(root, 'make-installer.bat');
const hasInstallerScript = await access(installerPath).then(() => true, () => false);
const installerScript = hasInstallerScript ? await readFile(installerPath, 'utf8') : '';
const rootPackage = JSON.parse(packageText);
const deferred = hasInstallerScript ? false : 'installer BAT intentionally deferred from Phase 0 preview-only package';

test('electron-builder is pinned as a local root dependency', () => {
  assert.equal(rootPackage.devDependencies?.['electron-builder'], '26.0.12');
});

test('installer runs the local electron-builder executable, not pnpm dlx', { skip: deferred }, () => {
  assert.match(installerScript, /pnpm exec electron-builder --config/i);
  assert.doesNotMatch(installerScript, /pnpm\s+dlx\s+electron-builder/i);
});

test('installer verifies the local builder exists and checks for the expected artifact', { skip: deferred }, () => {
  assert.match(installerScript, /pnpm exec electron-builder --version/i);
  assert.match(installerScript, /NEXORA-Setup-1\.2\.0-x64\.exe/i);
  assert.match(installerScript, /:e_builder_missing/i);
});
