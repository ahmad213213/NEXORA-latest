import test from 'node:test';
import assert from 'node:assert/strict';
import { access, readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const host = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const project = path.resolve(host, '../..');

test('live Electron renderer uses the DualSense-style Console Mode icon', async () => {
  const html = await readFile(path.join(project, 'apps/host/src/ui/index.html'), 'utf8');
  const css = await readFile(path.join(project, 'apps/host/src/ui/styles.css'), 'utf8');
  const icon = path.join(project, 'apps/host/src/ui/assets/dualsense-mode.svg');
  await access(icon);
  assert.match(html, /id="winConsoleBtn"[^>]*aria-label="Open Console Mode"[\s\S]*?<img class="dualsense-mode-icon" src="\.\/assets\/dualsense-mode\.svg"/);
  assert.match(css, /\.win-console \.dualsense-mode-icon\s*\{/);
  assert.match(await readFile(icon, 'utf8'), /<svg[\s\S]*?viewBox="0 0 72 46"/);
});

test('real settings implementation remains wired to protected Electron IPC', async () => {
  const main = await readFile(path.join(project, 'apps/host/src/main.ts'), 'utf8');
  const preload = await readFile(path.join(project, 'apps/host/src/preload.cts'), 'utf8');
  const app = await readFile(path.join(project, 'apps/host/src/ui/app.js'), 'utf8');
  for (const channel of ['config:get', 'config:set', 'settings:capabilities', 'settings:export', 'settings:import', 'settings:reset']) {
    assert.ok(main.includes(`ipcMain.handle('${channel}'`), `main registers ${channel}`);
  }
  for (const api of ['getConfig', 'setConfig', 'getSettingsCapabilities', 'exportSettings', 'importSettings', 'resetSettings']) {
    assert.ok(preload.includes(`${api}:`), `preload exposes ${api}`);
  }
  for (const category of ['General', 'Appearance', 'Streaming', 'Network', 'Updates', 'Privacy & security']) {
    assert.ok(app.includes(category), `renderer implements ${category}`);
  }
});
