import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import path from 'node:path';
const root = new URL('..', import.meta.url).pathname;
const read = file => readFile(path.join(root, file), 'utf8');

test('electron shell has layered security boundaries', async () => {
  const source = await read('src/main.ts');
  assert.match(source, /contextIsolation:\s*true/);
  assert.match(source, /nodeIntegration:\s*false/);
  assert.match(source, /sandbox:\s*true/);
  assert.match(source, /webSecurity:\s*true/);
  assert.match(source, /webviewTag:\s*false/);
  assert.match(source, /allowRunningInsecureContent:\s*false/);
  assert.match(source, /setPermissionRequestHandler/);
  assert.match(source, /setPermissionCheckHandler/);
});

test('single instance is authoritative and startup is blocked before window creation', async () => {
  const source = await read('src/main.ts');
  assert.match(source, /app\.requestSingleInstanceLock\(\)/);
  assert.ok(source.indexOf('app.requestSingleInstanceLock()') < source.indexOf('function createWindow'));
  assert.match(source, /second-instance/);
});

test('shutdown waits for cleanup before app.exit', async () => {
  const source = await read('src/main.ts');
  assert.match(source, /event\.preventDefault\(\)/);
  assert.match(source, /lifecycle\.shutdown\(/);
  assert.match(source, /\.then\(\(\) => app\.exit\(0\)\)/);
  assert.doesNotMatch(source, /setImmediate\(\(\) => app\.exit/);
});

test('ipc handlers verify trusted renderer and lifecycle state', async () => {
  const source = await read('src/main.ts');
  assert.match(source, /event\.sender === mainWindow\.webContents/);
  assert.match(source, /lifecycle\.canAcceptWork\(\)/);
  assert.match(source, /Unauthorized IPC request/);
});

test('host build copies the HTML entrypoint', async () => {
  const script = await read('scripts/copy-static.mjs');
  const pkg = JSON.parse(await read('package.json'));
  assert.match(pkg.scripts.build, /copy-static\.mjs/);
  assert.match(script, /src.*ui/);
  assert.match(script, /dist.*ui/);
});

test('main imports every exported configuration symbol', async () => {
  const source = await read('src/main.ts');
  assert.match(source, /saveConfig, normalize, type HostConfig/);
});

test('old-project foundation lessons have explicit contracts', async () => {
  const map = await read('../../docs/OLD-PROJECT-COMPATIBILITY.md');
  assert.match(map, /Device identity/);
  assert.match(map, /FFmpeg/);
  assert.match(map, /strict session state machine/i);
  assert.match(map, /Remote-access preference/);
});

test('Part 2 loads the real UI surface instead of the Part 1 placeholder', async () => {
  const source = await read('src/main.ts');
  assert.match(source, /ui.*index\.html/);
  const html = await read('src/ui/index.html');
  assert.match(html, /NEXORA/);
  assert.match(html, /Play Beyond Your Screen/);
  assert.match(html, /Continue Playing/);
  assert.match(html, /All Games/);
  assert.match(html, /FEATURED/);
});

test('Part 2 UI has deterministic performance guards', async () => {
  const css = await read('src/ui/styles.css');
  assert.doesNotMatch(css, /filter:\s*blur\(/);
  assert.match(css, /flex:0 0 148px/);
  assert.match(css, /scrollbar-width:\s*none/);
});

test('Part 2 UI remains an actual component surface, not a screenshot', async () => {
  const html = await read('src/ui/index.html');
  assert.match(html, /<aside class="sidebar"/);
  assert.match(html, /<section class="hero"/);
  assert.match(html, /id="gameRow"/);
  assert.match(html, /id="continueRow"/);
  assert.match(html, /id="addGameBtn"/);
  assert.doesNotMatch(html, /19437\.png/);
});

test('Part 3 library and metadata surfaces are wired without weakening the shell', async () => {
  const preload = await read('src/preload.cts');
  const main = await read('src/main.ts');
  const library = await read('src/library.ts');
  const metadata = await read('src/metadata.ts');
  const controller = await read('src/library-controller.ts');
  assert.match(preload, /library:list/);
  assert.match(preload, /library:add-dialog/);
  assert.match(preload, /library:select-candidate/);
  assert.match(main, /contextIsolation:\s*true/);
  assert.match(main, /library:add-dialog/);
  assert.match(main, /nexora-cover/);
  assert.match(library, /status: GameStatus/);
  assert.match(metadata, /acceptanceGate/);
  assert.match(metadata, /rankGlobally/);
  assert.match(controller, /pending/);
});

test('Part 3 metadata flow cannot commit unverified games', async () => {
  const metadata = await read('src/metadata.ts');
  assert.match(metadata, /platform !== 'windows'/);
  assert.match(metadata, /hasMeaningfulDescription/);
  assert.match(metadata, /validateCover/);
  assert.match(metadata, /sourceUrl/);
});
