import test from 'node:test';
import assert from 'node:assert/strict';
import { access, readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const project = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../..');
const ui = path.join(project, 'apps/host/src/ui');

test('Phase 1 live renderer loads the frosted-glass integration layer and wallpaper asset', async () => {
  const html = await readFile(path.join(ui, 'index.html'), 'utf8');
  const css = await readFile(path.join(ui, 'phase1-glass.css'), 'utf8');
  await access(path.join(ui, 'assets/nexora-wallpaper.png'));
  assert.match(html, /href="\.\/phase1-glass\.css"/);
  assert.match(css, /backdrop-filter:\s*blur\(var\(--glass-blur\)\)/);
  assert.match(css, /url\('\.\/assets\/nexora-wallpaper\.png'\)/);
  assert.match(html, /id="winConsoleBtn"[\s\S]*?dualsense-mode\.svg/);
});

test('Phase 1 exposes the collapsed icon-only sidebar and top-right PC name', async () => {
  const html = await readFile(path.join(ui, 'index.html'), 'utf8');
  const js = await readFile(path.join(ui, 'app.js'), 'utf8');
  const css = await readFile(path.join(ui, 'phase1-glass.css'), 'utf8');
  assert.match(html, /id="sidebarCollapseBtn"/);
  assert.match(html, /id="topPcName"/);
  assert.match(js, /nexora\.ui\.sidebarCollapsed/);
  assert.match(js, /getElementById\('quickQualityBtn'\)/);
  assert.match(css, /body\.sidebar-collapsed \{ --side: 76px; \}/);
  assert.match(css, /prefers-reduced-motion:\s*reduce/);
});

test('Phase 1 keeps settings on the protected Electron config IPC path', async () => {
  const main = await readFile(path.join(project, 'apps/host/src/main.ts'), 'utf8');
  const preload = await readFile(path.join(project, 'apps/host/src/preload.cts'), 'utf8');
  const js = await readFile(path.join(ui, 'app.js'), 'utf8');
  for (const channel of ['config:get', 'config:set', 'settings:capabilities', 'settings:export', 'settings:import', 'settings:reset']) {
    assert.ok(main.includes(`ipcMain.handle('${channel}'`), `main process registers ${channel}`);
  }
  for (const method of ['getConfig', 'setConfig', 'getSettingsCapabilities', 'exportSettings', 'importSettings', 'resetSettings']) {
    assert.ok(preload.includes(`${method}:`), `preload exposes ${method}`);
  }
  for (const category of ['General', 'Appearance', 'Streaming', 'Network', 'Updates', 'Privacy & security']) {
    assert.ok(js.includes(category), `renderer implements ${category}`);
  }
  assert.match(js, /window\.nexora\.setConfig\(patch\)/);
  assert.match(js, /window\.nexora\.exportSettings\(\)/);
  assert.match(js, /window\.nexora\.importSettings\(\)/);
  assert.match(js, /window\.nexora\.resetSettings\(\)/);
});

