@echo off
setlocal EnableExtensions
chcp 65001 >nul
title NEXORA - Windows Installer Builder
color 0B

rem NEXORA Phase 1 defensive installer builder.
rem Keep this BAT in the project ROOT next to package.json.
set "ROOT=%~dp0"
if "%ROOT:~-1%"=="\" set "ROOT=%ROOT:~0,-1%"
set "WORK=%ROOT%\installer-work"
set "APP=%WORK%\app"
set "OUT=%ROOT%\Installer"
set "LOG=%ROOT%\installer-build.log"
set "CFG=%WORK%\electron-builder.yml"
set "NEXORA_ROOT=%ROOT%"
set "TARGET=%OUT%\NEXORA-Setup-1.2.0-x64.exe"

cls
echo ================================================================
echo              NEXORA WINDOWS INSTALLER BUILDER
echo ================================================================
echo Project: "%ROOT%"
echo Output:  "%OUT%"
echo Log:     "%LOG%"
echo.

if not exist "%ROOT%\package.json" goto :no_pkg
where node >nul 2>&1
if errorlevel 1 goto :no_node
for /f "tokens=1 delims=v" %%V in ('node -v') do set "NODEVER=%%V"
for /f "tokens=1 delims=." %%V in ("%NODEVER%") do set "NODEMAJOR=%%V"
if not defined NODEMAJOR goto :no_nodever
if %NODEMAJOR% LSS 22 goto :old_node
where corepack >nul 2>&1
if errorlevel 1 goto :no_corepack

>"%LOG%" echo NEXORA installer build log
>>"%LOG%" echo Started: %DATE% %TIME%
>>"%LOG%" echo Project: %ROOT%
>>"%LOG%" echo Packaging mode: project-local electron-builder; pnpm dlx is intentionally not used.

pushd "%ROOT%"
if errorlevel 1 goto :fail_no_log

echo [1/7] Preparing pnpm 10.17.1...
call corepack prepare pnpm@10.17.1 --activate >>"%LOG%" 2>&1
if errorlevel 1 goto :e_pnpm

echo [2/7] Installing workspace dependencies and pinned electron-builder...
call corepack pnpm install --no-frozen-lockfile >>"%LOG%" 2>&1
if errorlevel 1 goto :e_install

echo [3/7] Verifying local NSIS StdUtils.nsh include...
call :check_stdutils
if errorlevel 1 goto :repair_stdutils
goto :stdutils_ok

:repair_stdutils
echo Local NSIS include missing; attempting one forced dependency repair...
>>"%LOG%" echo StdUtils.nsh missing; retrying with pnpm install --force.
call corepack pnpm install --force --no-frozen-lockfile >>"%LOG%" 2>&1
if errorlevel 1 goto :e_repair
call :check_stdutils
if errorlevel 1 goto :e_stdutils

:stdutils_ok
echo [4/7] Building NEXORA TypeScript sources...
call corepack pnpm build >>"%LOG%" 2>&1
if errorlevel 1 goto :e_build
if not exist "%ROOT%\apps\host\dist\main.js" goto :e_nomain
if not exist "%ROOT%\packages\shared\dist\index.js" goto :e_noshared

echo [5/7] Preparing isolated app staging folder...
rem Clean only this script's generated staging app. Keep all existing Installer files.
if not exist "%WORK%" mkdir "%WORK%" 2>nul
if exist "%APP%" rmdir /s /q "%APP%"
mkdir "%APP%" 2>nul
if not exist "%APP%" goto :e_stage
if not exist "%OUT%" mkdir "%OUT%" 2>nul
xcopy "%ROOT%\apps\host\dist" "%APP%\dist\" /E /I /H /Y >nul
if errorlevel 1 goto :e_stage_app
call node "%ROOT%\scripts\release\vendor-shared.mjs" "%APP%" "%ROOT%\packages\shared\dist" >>"%LOG%" 2>&1
if errorlevel 1 goto :e_stage_shared

rem Create the app manifest line-by-line to handle Windows paths containing parentheses.
set "PJ=%APP%\package.json"
>"%PJ%"  echo {
>>"%PJ%" echo   "name": "nexora-host",
>>"%PJ%" echo   "productName": "NEXORA",
>>"%PJ%" echo   "version": "1.2.0",
>>"%PJ%" echo   "private": true,
>>"%PJ%" echo   "type": "module",
>>"%PJ%" echo   "description": "NEXORA game streaming host",
>>"%PJ%" echo   "main": "dist/main.js",
>>"%PJ%" echo   "author": "NEXORA",
>>"%PJ%" echo   "license": "UNLICENSED",
>>"%PJ%" echo   "devDependencies": { "electron": "38.2.0" }
>>"%PJ%" echo }

rem Config lives inside installer-work; this does not overwrite a project-owned config.
rem Absolute Windows paths are converted to forward slashes for valid YAML strings.
set "APP_FS=%APP:\=/%"
set "OUT_FS=%OUT:\=/%"
set "BUILD_FS=%ROOT%\build"
set "BUILD_FS=%BUILD_FS:\=/%"
>"%CFG%"  echo appId: com.nexora.host
>>"%CFG%" echo productName: NEXORA
>>"%CFG%" echo directories:
>>"%CFG%" echo   app: "%APP_FS%"
>>"%CFG%" echo   output: "%OUT_FS%"
>>"%CFG%" echo   buildResources: "%BUILD_FS%"
>>"%CFG%" echo files:
>>"%CFG%" echo   - "**/*"
>>"%CFG%" echo   - "!**/*.map"
>>"%CFG%" echo   - "!**/test/**"
>>"%CFG%" echo   - "!**/*.ts"
>>"%CFG%" echo asar: true
>>"%CFG%" echo npmRebuild: false
>>"%CFG%" echo buildDependenciesFromSource: false
>>"%CFG%" echo electronVersion: 38.2.0
>>"%CFG%" echo win:
>>"%CFG%" echo   signAndEditExecutable: false
>>"%CFG%" echo   target:
>>"%CFG%" echo     - target: nsis
>>"%CFG%" echo       arch:
>>"%CFG%" echo         - x64
>>"%CFG%" echo   artifactName: "NEXORA-Setup-${version}-x64.${ext}"
>>"%CFG%" echo nsis:
>>"%CFG%" echo   oneClick: false
>>"%CFG%" echo   perMachine: false
>>"%CFG%" echo   allowToChangeInstallationDirectory: true
>>"%CFG%" echo   createDesktopShortcut: true
>>"%CFG%" echo   createStartMenuShortcut: true
>>"%CFG%" echo   shortcutName: NEXORA
>>"%CFG%" echo   deleteAppDataOnUninstall: false
>>"%CFG%" echo   runAfterFinish: true
>>"%CFG%" echo   installerIcon: "%BUILD_FS%/installerIcon.ico"
>>"%CFG%" echo   uninstallerIcon: "%BUILD_FS%/installerIcon.ico"
>>"%CFG%" echo   installerHeaderIcon: "%BUILD_FS%/installerIcon.ico"
>>"%CFG%" echo   displayLanguageSelector: false
>>"%CFG%" echo   installerLanguages:
>>"%CFG%" echo     - en_US
>>"%CFG%" echo   shortcutName: NEXORA
>>"%CFG%" echo icon: "%BUILD_FS%/icon.ico"
>>"%CFG%" echo electronLanguages:
>>"%CFG%" echo   - en-US

rem Preserve any previous installer without deleting the Installer directory.
if exist "%TARGET%" goto :backup_existing
goto :do_packaging
:backup_existing
set "OLD_TARGET=%OUT%\NEXORA-Setup-1.2.0-x64.previous-%RANDOM%.exe"
move "%TARGET%" "%OLD_TARGET%" >>"%LOG%" 2>&1
if errorlevel 1 goto :e_backup

:do_packaging
echo [6/7] Packaging with the project-local, pinned electron-builder...
call corepack pnpm exec electron-builder --version >>"%LOG%" 2>&1
if errorlevel 1 goto :e_builder_missing
call corepack pnpm exec electron-builder --config "%CFG%" --win nsis --x64 >>"%LOG%" 2>&1
if errorlevel 1 goto :e_pack
if not exist "%TARGET%" goto :e_noexe

>>"%LOG%" echo SUCCESS: installer exists at %TARGET%
echo [7/7] Finished successfully.
echo Installer: "%TARGET%"
echo Log:       "%LOG%"
echo Previous installers, if any, were preserved as .previous files.
echo Note: the installer is unsigned; Windows SmartScreen may warn.
popd
start "" "%OUT%"
pause
exit /b 0

:no_pkg
echo [ERROR] package.json was not found. Keep this BAT in the NEXORA project root.
goto :fail_no_log
:no_node
echo [ERROR] Install Node.js 22 or newer from https://nodejs.org/
goto :fail_no_log
:no_nodever
echo [ERROR] Could not detect the Node.js version.
goto :fail_no_log
:old_node
echo [ERROR] Node.js 22+ is required. Current version: %NODEVER%
goto :fail_no_log
:no_corepack
echo [ERROR] Corepack is missing. Reinstall Node.js 22+ with Corepack enabled.
goto :fail_no_log
:e_pnpm
echo [ERROR] Could not activate pnpm. See installer-build.log
goto :fail
:e_install
echo [ERROR] Dependency installation failed. See installer-build.log
goto :fail
:e_repair
echo [ERROR] Forced dependency repair failed. See installer-build.log
goto :fail
:e_stdutils
echo [ERROR] StdUtils.nsh is still missing after forced repair. See installer-build.log
echo The local electron-builder dependency tree is incomplete. No NSIS build was attempted.
goto :fail
:e_build
echo [ERROR] Source build failed. See installer-build.log
goto :fail
:e_nomain
echo [ERROR] apps\host\dist\main.js was not created.
goto :fail
:e_noshared
echo [ERROR] packages\shared\dist\index.js was not created.
goto :fail
:e_stage
echo [ERROR] Could not create staging folder.
goto :fail
:e_stage_app
echo [ERROR] Could not stage compiled app.
goto :fail
:e_stage_shared
echo [ERROR] Could not bundle the shared package. See installer-build.log
goto :fail
:e_backup
echo [ERROR] Could not preserve the previous installer before packaging.
goto :fail
:e_builder_missing
echo [ERROR] Local electron-builder is missing. See installer-build.log
goto :fail
:e_pack
echo [ERROR] NSIS/electron-builder packaging failed. See installer-build.log
goto :fail
:e_noexe
echo [ERROR] electron-builder exited but expected installer was not found. See installer-build.log
goto :fail

:fail
>>"%LOG%" echo FAILED: %DATE% %TIME%
if defined OLD_TARGET if exist "%OLD_TARGET%" if not exist "%TARGET%" move "%OLD_TARGET%" "%TARGET%" >nul
popd
:fail_no_log
echo.
echo BUILD FAILED. No successful installer is being claimed.
echo Log: "%LOG%"
pause
exit /b 1

:check_stdutils
powershell -NoProfile -ExecutionPolicy Bypass -Command "$base = Join-Path $env:NEXORA_ROOT 'node_modules\.pnpm'; if (-not (Test-Path -LiteralPath $base)) { Write-Error 'pnpm local dependency store not found'; exit 1 }; $f = Get-ChildItem -LiteralPath $base -Filter 'StdUtils.nsh' -File -Recurse -ErrorAction SilentlyContinue | Where-Object { $_.FullName -match '\\app-builder-lib@[^\\]+\\node_modules\\app-builder-lib\\templates\\nsis\\include\\StdUtils\.nsh$' } | Select-Object -First 1 -ExpandProperty FullName; if ([string]::IsNullOrWhiteSpace($f)) { Write-Error 'app-builder-lib/templates/nsis/include/StdUtils.nsh is missing from the local install'; exit 2 }; Write-Output ('Verified NSIS include: ' + $f)" >>"%LOG%" 2>&1
exit /b %errorlevel%
