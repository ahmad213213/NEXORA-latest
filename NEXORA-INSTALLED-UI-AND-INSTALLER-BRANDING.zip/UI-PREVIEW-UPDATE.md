# NEXORA UI Preview Update — Empty Library + Rotating Backgrounds

## Scope

This is a UI-testing delivery, not game implementation, not a layout redesign, and not a completed Electron UI merge. The existing frosted-glass prototype remains the visual source of truth. `PREVIEW.bat` now opens this approved prototype rather than the legacy renderer at `apps/host/src/ui/index.html`.

## Changes

- Removed all preloaded demonstration game records/cards from the Dashboard, Library, and Console Mode.
- Preserved the existing UI layout, typography, spacing, navigation, animations, and DualSense-style mode switch.
- Added four local 1920×1080 wallpaper assets: Space Horizon, Nebula, Forest Vista, and Earth Orbit.
- Rotates sequentially per open, remembers the last selection through local storage, and wraps after Earth Orbit.
- The wallpaper is applied to the hero/default background and Console backdrop while the library is empty.
- Add Game buttons are placeholders only; clicking them explains that game adding will come later.
- No build or installer BAT files were added. `PREVIEW.bat` is the only `.bat` file in the project.

## Run

Extract the ZIP and double-click `PREVIEW.bat`. It opens `design-reference/current-frosted-glass-ui-prototype/index.html`. No dependency installation is required.

## Limitations

The prototype does not connect to real Electron IPC or perform game adding/launching. The underlying live renderer and prototype have deliberately not been declared merged. Final integration belongs to the next application phase after the UI is approved.
