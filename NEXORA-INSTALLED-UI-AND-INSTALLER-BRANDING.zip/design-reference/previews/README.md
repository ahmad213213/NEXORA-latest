# Current preview references

`background-rotation-options.png` shows the four local wallpapers used by the empty-library UI preview. The old populated-mockup screenshots are preserved separately in `../reference-screenshots-original/` for historical design reference; they are not the current empty-library runtime state.
