'use strict';

// Example only: merge this `settings` property into the existing
// contextBridge.exposeInMainWorld('nexora', ...) call in NEXORA's preload.
// Do NOT add a second exposure of the same global if one already exists.
const { contextBridge, ipcRenderer } = require('electron');

const settingsApi = Object.freeze({
  getAll: () => ipcRenderer.invoke('nexora:settings:getAll'),
  setAll: (settings) => ipcRenderer.invoke('nexora:settings:setAll', settings),
});

// This standalone example assumes `window.nexora` is not exposed elsewhere.
// If NEXORA already has a preload API, copy `settings: settingsApi` into that
// existing object instead of using this exposeInMainWorld call.
contextBridge.exposeInMainWorld('nexora', Object.freeze({ settings: settingsApi }));
