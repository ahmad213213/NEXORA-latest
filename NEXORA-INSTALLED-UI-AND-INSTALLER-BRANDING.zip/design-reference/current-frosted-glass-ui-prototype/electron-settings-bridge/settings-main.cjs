'use strict';

// Secure main-process settings storage starter for NEXORA.
// Register this after app.whenReady() in the actual Electron main process.
// It does not expose filesystem access to renderer code.

const fs = require('node:fs/promises');
const path = require('node:path');
const { fileURLToPath } = require('node:url');

const GET_CHANNEL = 'nexora:settings:getAll';
const SET_CHANNEL = 'nexora:settings:setAll';

const DEFAULTS = Object.freeze({
  theme: 'midnight',
  accent: 'cyan',
  reducedMotion: false,
  desktopModeOnStartup: true,
  startWithWindows: false,
  minimizeToTray: false,
  language: 'English',
  profileName: 'NEXORA User',
  connectionMode: 'automatic',
  relayFallback: true,
  pairingCodeLifetime: '5',
  resolution: '1080p',
  frameRate: '60',
  bitrateMbps: 25,
  encoder: 'auto',
  audioCapture: 'system',
  adaptiveQuality: true,
  updateChannel: 'stable',
  automaticUpdateChecks: true,
  requireDeviceApproval: true,
  encryptSessions: true,
  diagnosticLogging: false,
  shareCrashReports: false,
});

const ENUMS = Object.freeze({
  theme: ['midnight', 'obsidian', 'earth'],
  accent: ['cyan', 'blue', 'violet', 'amber', 'emerald', 'rose'],
  language: ['English', 'Spanish', 'French'],
  connectionMode: ['automatic', 'direct', 'relay'],
  pairingCodeLifetime: ['2', '5', '10'],
  resolution: ['720p', '1080p', '1440p', '2160p'],
  frameRate: ['30', '60', '120'],
  encoder: ['auto', 'nvenc', 'amf', 'qsv', 'software'],
  audioCapture: ['system', 'application', 'muted'],
  updateChannel: ['stable', 'beta'],
});

const BOOLEAN_KEYS = Object.freeze(Object.keys(DEFAULTS).filter((key) => typeof DEFAULTS[key] === 'boolean'));
const own = (object, key) => Object.prototype.hasOwnProperty.call(object, key);

function sanitiseSettings(incoming) {
  const result = { ...DEFAULTS };
  if (!incoming || typeof incoming !== 'object' || Array.isArray(incoming)) return result;

  for (const key of Object.keys(DEFAULTS)) {
    if (!own(incoming, key)) continue;
    const value = incoming[key];
    if (BOOLEAN_KEYS.includes(key)) {
      if (typeof value === 'boolean') result[key] = value;
      continue;
    }
    if (own(ENUMS, key)) {
      if (ENUMS[key].includes(String(value))) result[key] = String(value);
      continue;
    }
    if (key === 'profileName') {
      if (typeof value === 'string') {
        result.profileName = value.replace(/[\u0000-\u001f\u007f]/g, '').trim().slice(0, 40) || DEFAULTS.profileName;
      }
      continue;
    }
    if (key === 'bitrateMbps') {
      const numeric = Number(value);
      if (Number.isFinite(numeric)) {
        const bounded = Math.max(5, Math.min(100, numeric));
        result.bitrateMbps = Math.max(5, Math.min(100, Math.round((bounded - 5) / 5) * 5 + 5));
      }
    }
  }
  return result;
}

function defaultTrustedSender(event, app) {
  const rawUrl = event?.senderFrame?.url || event?.sender?.getURL?.() || '';
  try {
    const url = new URL(rawUrl);
    if (url.protocol === 'file:') {
      // Only allow packaged/local UI files located inside the app directory.
      const appRoot = path.resolve(app.getAppPath());
      const rendererPath = path.resolve(fileURLToPath(url));
      const relative = path.relative(appRoot, rendererPath);
      return relative === '' || (relative !== '..' && !relative.startsWith(`..${path.sep}`) && !path.isAbsolute(relative));
    }
    // Development convenience only. Supply a stricter isTrustedSender callback
    // when registering if the actual dev origin is known.
    return url.protocol === 'http:' && ['localhost', '127.0.0.1', '[::1]'].includes(url.hostname);
  } catch {
    return false;
  }
}

function registerNexoraSettingsIpc({ app, ipcMain, isTrustedSender = defaultTrustedSender }) {
  if (!app?.getPath || !ipcMain?.handle) {
    throw new TypeError('registerNexoraSettingsIpc requires Electron app and ipcMain.');
  }

  const settingsPath = path.join(app.getPath('userData'), 'settings-v1.json');
  let currentSettings;
  let isLoaded = false;
  let writeQueue = Promise.resolve();

  async function readSettings() {
    if (isLoaded) return { ...currentSettings };
    try {
      const raw = await fs.readFile(settingsPath, 'utf8');
      let parsed;
      try {
        parsed = JSON.parse(raw);
      } catch (error) {
        const quarantine = `${settingsPath}.corrupt-${Date.now()}.json`;
        try { await fs.rename(settingsPath, quarantine); } catch { /* preserve original failure context */ }
        currentSettings = { ...DEFAULTS };
        isLoaded = true;
        return { ...currentSettings };
      }
      if (!parsed || parsed.schemaVersion !== 1 || !parsed.settings || typeof parsed.settings !== 'object') {
        // Quarantine an incompatible version rather than silently overwriting it
        // with defaults on the next save.
        const quarantine = `${settingsPath}.unsupported-${Date.now()}.json`;
        try { await fs.rename(settingsPath, quarantine); } catch { /* keep defaults if quarantine is unavailable */ }
        currentSettings = { ...DEFAULTS };
      } else {
        currentSettings = sanitiseSettings(parsed.settings);
      }
    } catch (error) {
      if (error?.code !== 'ENOENT') throw error;
      currentSettings = { ...DEFAULTS };
    }
    isLoaded = true;
    return { ...currentSettings };
  }

  async function writeSettings(incoming) {
    if (!incoming || typeof incoming !== 'object' || Array.isArray(incoming)) {
      throw new TypeError('Settings payload must be a plain object.');
    }
    const sanitized = sanitiseSettings(incoming);
    const job = writeQueue.then(async () => {
      await fs.mkdir(path.dirname(settingsPath), { recursive: true });
      const tempPath = `${settingsPath}.tmp-${process.pid}`;
      const payload = JSON.stringify({ schemaVersion: 1, savedAt: new Date().toISOString(), settings: sanitized }, null, 2);
      try {
        await fs.writeFile(tempPath, payload, { encoding: 'utf8', mode: 0o600 });
        await fs.rename(tempPath, settingsPath);
      } catch (error) {
        try { await fs.unlink(tempPath); } catch { /* temporary file may not exist */ }
        throw error;
      }
      currentSettings = sanitized;
      isLoaded = true;
      return { ok: true };
    });
    writeQueue = job.catch(() => {});
    return job;
  }

  const authorize = (event) => {
    if (!isTrustedSender(event, app)) throw new Error('Untrusted renderer cannot access NEXORA settings.');
  };

  ipcMain.removeHandler?.(GET_CHANNEL);
  ipcMain.removeHandler?.(SET_CHANNEL);
  ipcMain.handle(GET_CHANNEL, async (event) => {
    authorize(event);
    await writeQueue;
    return readSettings();
  });
  ipcMain.handle(SET_CHANNEL, async (event, settings) => {
    authorize(event);
    return writeSettings(settings);
  });

  return {
    settingsPath,
    async dispose() {
      await writeQueue;
      ipcMain.removeHandler?.(GET_CHANNEL);
      ipcMain.removeHandler?.(SET_CHANNEL);
    },
  };
}

module.exports = { registerNexoraSettingsIpc, sanitiseSettings, DEFAULTS };
