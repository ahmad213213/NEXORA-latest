"use strict";
const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");

const protoDir = path.resolve(__dirname, "..");
const projectRoot = path.resolve(protoDir, "../..");
const htmlPath = path.join(protoDir, "index.html");
const rotationPath = path.join(protoDir, "background-rotation.js");
const backgrounds = [
  { id: "space-horizon", name: "Space Horizon", src: "assets/backgrounds/space-horizon.jpg" },
  { id: "nebula", name: "Nebula", src: "assets/backgrounds/nebula.jpg" },
  { id: "forest-vista", name: "Forest Vista", src: "assets/backgrounds/forest-vista.jpg" },
  { id: "earth-orbit", name: "Earth Orbit", src: "assets/backgrounds/earth-orbit.jpg" },
];

function runRotation(storage) {
  const values = {};
  const root = { style: { setProperty: (key, value) => { values[key] = value; } }, dataset: {} };
  const window = { localStorage: storage };
  vm.runInNewContext(fs.readFileSync(rotationPath, "utf8"), { window, document: { documentElement: root }, Date, Math, Number, Object });
  return { selected: window.NEXORAEmptyBackground, vars: values, dataset: root.dataset };
}

function createStorage(map) {
  return {
    getItem(key) { return map.has(key) ? map.get(key) : null; },
    setItem(key, value) { map.set(key, String(value)); },
  };
}

test("default background advances on each open in the requested sequence", () => {
  const persisted = new Map();
  const chosen = [];
  for (let i = 0; i < 5; i++) chosen.push(runRotation(createStorage(persisted)).selected.id);
  assert.deepEqual(chosen, ["space-horizon", "nebula", "forest-vista", "earth-orbit", "space-horizon"]);
});

test("selected wallpaper is applied to the CSS variable and exposed for preview verification", () => {
  const result = runRotation(createStorage(new Map()));
  assert.equal(result.vars["--nexora-empty-wallpaper"], 'url("assets/backgrounds/space-horizon.jpg")');
  assert.equal(result.dataset.nexoraEmptyBackground, "space-horizon");
  assert.equal(result.dataset.nexoraEmptyBackgroundName, "Space Horizon");
});

test("preview falls back cleanly if localStorage throws", () => {
  const storage = { getItem() { throw new Error("blocked"); }, setItem() { throw new Error("blocked"); } };
  const result = runRotation(storage);
  assert.ok(backgrounds.some(item => item.id === result.selected.id));
  assert.match(result.vars["--nexora-empty-wallpaper"], /^url\("assets\/backgrounds\//);
});

test("Desktop, Library, and Console are empty by default (no sample game records)", () => {
  const html = fs.readFileSync(htmlPath, "utf8");
  const classAttributes = [...html.matchAll(/class="([^"]*)"/g)].map(match => match[1].split(/\s+/));
  for (const className of ["game-tile", "library-card", "console-cover", "mini-cover"]) {
    assert.equal(classAttributes.some(classes => classes.includes(className)), false, `${className} should not be present`);
  }
  for (const title of ["Halo Infinite", "Elden Ring", "God of War Ragnarök", "Red Dead Redemption", "Cyberpunk 2077", "Forza Horizon", "The Witcher", "Starfield"]) {
    assert.equal(html.toLowerCase().includes(title.toLowerCase()), false, `${title} must not be preloaded`);
  }
  assert.match(html, /No games added yet/);
  assert.match(html, /Your library is empty/);
});

test("all four local wallpapers are present as real JPEG files", () => {
  for (const item of backgrounds) {
    const asset = path.join(protoDir, item.src);
    const buffer = fs.readFileSync(asset);
    assert.equal(buffer[0], 0xff, `${item.name} must begin with JPEG marker`);
    assert.equal(buffer[1], 0xd8, `${item.name} must begin with JPEG marker`);
    assert.ok(buffer.length > 100_000, `${item.name} is unexpectedly small`);
  }
});

test("PREVIEW.bat opens the approved prototype and is the only batch file", () => {
  const bat = fs.readFileSync(path.join(projectRoot, "PREVIEW.bat"), "utf8");
  assert.match(bat, /design-reference\\current-frosted-glass-ui-prototype\\index\.html/i);
  assert.doesNotMatch(bat, /apps\\host\\src\\ui\\index\.html/i);
  const bats = [];
  function walk(dir) {
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) walk(full);
      else if (entry.name.toLowerCase().endsWith(".bat")) bats.push(path.relative(projectRoot, full));
    }
  }
  walk(projectRoot);
  assert.deepEqual(bats, ["PREVIEW.bat"]);
});
