export interface DeviceIdentityRecord {
  schema: 1;
  deviceId: string;
  publicKey: string;
  algorithm: 'Ed25519';
  createdAt: number;
}

export interface SignedSessionContext {
  deviceId: string;
  sessionId: string;
  sequence: number;
  messageType: string;
  signature: string;
}
