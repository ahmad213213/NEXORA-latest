export type InputKind = 'key' | 'mouse-button' | 'mouse-move' | 'gamepad-button' | 'gamepad-axis' | 'touch';
export type InputAction = 'down' | 'up' | 'move';
export interface InputEvent {
  kind: InputKind;
  action: InputAction;
  code: string;
  value?: number;
  x?: number;
  y?: number;
  sequence: number;
  timestamp: number;
}

const CODE_RE = /^[A-Za-z0-9_.:-]{1,48}$/;
export function isValidInputEvent(v: unknown): v is InputEvent {
  if (!v || typeof v !== 'object') return false;
  const x = v as Record<string, unknown>;
  if (!['key','mouse-button','mouse-move','gamepad-button','gamepad-axis','touch'].includes(String(x.kind))) return false;
  if (!['down','up','move'].includes(String(x.action))) return false;
  if (typeof x.code !== 'string' || !CODE_RE.test(x.code)) return false;
  if (!Number.isSafeInteger(x.sequence) || Number(x.sequence) < 0) return false;
  if (!Number.isSafeInteger(x.timestamp) || Number(x.timestamp) < 0) return false;
  if (x.value !== undefined && (typeof x.value !== 'number' || !Number.isFinite(x.value) || Math.abs(x.value) > 1)) return false;
  if (x.x !== undefined && (typeof x.x !== 'number' || x.x < 0 || x.x > 1)) return false;
  if (x.y !== undefined && (typeof x.y !== 'number' || x.y < 0 || x.y > 1)) return false;
  return true;
}
