import { isValidInputEvent, type InputEvent } from './input.js';

export const INPUT_CHANNEL = 'nexora-input-v1';
export const MAX_INPUT_FRAME_BYTES = 8192;

export function encodeInputFrame(event: InputEvent): string {
  if (!isValidInputEvent(event)) throw new Error('Invalid input event');
  const frame = JSON.stringify({ v: 1, type: 'input', event });
  if (new TextEncoder().encode(frame).byteLength > MAX_INPUT_FRAME_BYTES) throw new Error('Input frame too large');
  return frame;
}

export function decodeInputFrame(raw: string): InputEvent | null {
  if (typeof raw !== 'string' || new TextEncoder().encode(raw).byteLength > MAX_INPUT_FRAME_BYTES) return null;
  try {
    const value = JSON.parse(raw) as Record<string, unknown>;
    if (value.v !== 1 || value.type !== 'input' || !isValidInputEvent(value.event)) return null;
    return value.event;
  } catch { return null; }
}
