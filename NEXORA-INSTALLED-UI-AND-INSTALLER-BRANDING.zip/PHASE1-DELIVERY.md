# NEXORA UI preview delivery

This cumulative source package lets you test the intended frosted-glass UI with an empty library and rotating default backgrounds. It does not yet merge the prototype DOM into the live Electron renderer; that is intentionally deferred until the UI has been approved.

Run `PREVIEW.bat` to open the prototype. No game is preloaded and Add Game controls are placeholders. Wallpaper sequence: Space Horizon, Nebula, Forest Vista, Earth Orbit, then repeat.
